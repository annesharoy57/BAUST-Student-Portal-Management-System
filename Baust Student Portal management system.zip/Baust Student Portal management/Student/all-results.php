<?php 
session_start();
if (isset($_SESSION['student_id']) && isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Student') {
     include "../DB_connection.php";
     include "data/score.php";
     include "data/subject.php";
     include "data/fee.php";

     $student_id = $_SESSION['student_id'];
     
     // Get student's current level and term
     $current_level_term = getStudentCurrentLevelTerm($student_id, $conn);
     $current_level = $current_level_term['level'];
     $current_term = $current_level_term['term'];
     $current_semester = (($current_level - 1) * 2) + $current_term;

     // Get ALL scores with complete details
     $scores = getAllStudentScoresWithDetails($student_id, $conn);

     // Calculate Cumulative CGPA for all completed semesters
     $cgpa_data = calculateStudentCGPA($scores);
     $cumulative_cgpa = $cgpa_data['cgpa'];

     // Get student's fee status for all semesters
     $fee_status = getStudentFeeStatus($student_id, $conn);

     // Group scores by semester (1st to 8th semester) with fee check
     $semester_scores = [];
     $semester_access = []; // Track which semesters are accessible
     
     foreach ($scores as $score) {
         $level = intval($score['level'] ?? 1);
         $term_str = $score['term'] ?? 'I';
         $term = ($term_str == 'I' || $term_str == '1') ? 1 : 2;
         
         // Convert Level-Term to Semester (1-8)
         $semester = (($level - 1) * 2) + $term;
         
         // Check if student can view this semester's results
         $can_view = canViewSemesterResults($student_id, $semester, $conn);
         $semester_access[$semester] = $can_view;
         
         if ($can_view) {
             $semester_scores[$semester][] = $score;
         }
     }

     // Define all 8 semesters
     $all_semesters = [
         1 => ['name' => '1st Semester', 'level_term' => 'Level 1 - Term I'],
         2 => ['name' => '2nd Semester', 'level_term' => 'Level 1 - Term II'], 
         3 => ['name' => '3rd Semester', 'level_term' => 'Level 2 - Term I'],
         4 => ['name' => '4th Semester', 'level_term' => 'Level 2 - Term II'],
         5 => ['name' => '5th Semester', 'level_term' => 'Level 3 - Term I'],
         6 => ['name' => '6th Semester', 'level_term' => 'Level 3 - Term II'],
         7 => ['name' => '7th Semester', 'level_term' => 'Level 4 - Term I'],
         8 => ['name' => '8th Semester', 'level_term' => 'Level 4 - Term II']
     ];
     
     // Calculate semester GPA for each semester (only for accessible semesters)
     $semester_gpas = [];
     foreach ($all_semesters as $semester_num => $semester_info) {
         $semester_data = $semester_scores[$semester_num] ?? [];
         $semester_gpa = 0;
         $total_credits = 0;
         $total_points = 0;
         
         foreach ($semester_data as $score) {
             $credit_hours = floatval($score['credit_hours'] ?? 0);
             $grade_point = floatval($score['grade_point'] ?? 0);
             
             if ($grade_point > 0) {
                 $total_credits += $credit_hours;
                 $total_points += ($credit_hours * $grade_point);
             }
         }
         
         if ($total_credits > 0) {
             $semester_gpa = $total_points / $total_credits;
         }
         
         $semester_gpas[$semester_num] = number_format($semester_gpa, 2);
     }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student - Grade Summary</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    .semester-section { 
        margin-bottom: 30px; 
        border: 2px solid #dee2e6; 
        border-radius: 10px; 
    }
    .semester-section.current-semester {
        border: 3px solid #007bff;
        box-shadow: 0 0 20px rgba(0, 123, 255, 0.3);
        background-color: #f8f9fa;
    }
    .semester-section.completed {
        border: 2px solid #28a745;
        background-color: #f8fff9;
    }
    .semester-section.upcoming {
        border: 2px dashed #6c757d;
        background-color: #f8f9fa;
        opacity: 0.8;
    }
    .semester-section.restricted {
        border: 2px dashed #dc3545;
        background-color: #fff5f5;
        opacity: 0.7;
    }
    .semester-header { 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
        color: white; 
        border-radius: 8px 8px 0 0; 
        padding: 15px 20px;
    }
    .current-semester .semester-header {
        background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
    }
    .completed .semester-header {
        background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
    }
    .upcoming .semester-header {
        background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
    }
    .restricted .semester-header {
        background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    }
    .grade-A { background-color: #28a745 !important; color: white; }
    .grade-B { background-color: #17a2b8 !important; color: white; }
    .grade-C { background-color: #ffc107 !important; color: black; }
    .grade-D { background-color: #fd7e14 !important; color: white; }
    .grade-F { background-color: #dc3545 !important; color: white; }
    .course-code { font-family: 'Courier New', monospace; font-weight: bold; }
    .payment-alert {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 20px;
    }
    .semester-gpa {
        font-size: 1.1em;
        padding: 8px 16px;
        background: linear-gradient(135deg, #17a2b8 0%, #6f42c1 100%);
    }
    .current-semester-badge {
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
  </style>
</head>
<body>
    <?php include "inc/navbar.php"; ?>
    
    <div class="container mt-4">
        <!-- Payment Status Alert -->
        <?php if (!empty($fee_status)): ?>
            <?php 
            $current_sem_fee = $fee_status[$current_semester] ?? null;
            if ($current_sem_fee && !$current_sem_fee['can_view']): ?>
            <div class="payment-alert">
                <h5><i class="fa fa-exclamation-triangle text-warning"></i> Payment Notice</h5>
                <p class="mb-1">Your access to <strong><?= $all_semesters[$current_semester]['name'] ?? 'Current Semester' ?></strong> results is restricted due to outstanding fees.</p>
                <p class="mb-0">
                    <strong>Due Amount:</strong> ৳<?= number_format($current_sem_fee['due_amount'], 2) ?> | 
                    <strong>Status:</strong> <?= ucfirst($current_sem_fee['payment_status']) ?>
                </p>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (!empty($scores)): ?>
        
        <!-- Overall CGPA Card (Only show if student has access to at least one semester) -->
        <?php if (count($semester_scores) > 0): ?>
        <div class="card shadow mb-4 border-success">
            <div class="card-body text-center bg-success text-white">
                <h1 class="mb-3"><i class="fa fa-trophy"></i> Overall Academic Performance</h1>
                <h2 class="display-4 mb-4">Cumulative CGPA: <strong><?= number_format($cumulative_cgpa, 2) ?></strong></h2>
                <div class="row justify-content-center">
                    <div class="col-md-3">
                        <div class="border rounded p-3 bg-light text-dark">
                            <h6>Accessible Courses</h6>
                            <h3 class="text-primary"><?= array_sum(array_map('count', $semester_scores)) ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3 bg-light text-dark">
                            <h6>Completed Courses</h6>
                            <h3 class="text-info"><?= $cgpa_data['completed_courses'] ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3 bg-light text-dark">
                            <h6>Total Credits</h6>
                            <h3 class="text-warning"><?= number_format($cgpa_data['total_credits'], 1) ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3 bg-light text-dark">
                            <h6>Accessible Semesters</h6>
                            <h3 class="text-danger"><?= count($semester_scores) ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fa fa-graduation-cap"></i> My Grade Summary</h4>
                <p class="mb-0 mt-2">Current Semester: 
                    <?= $all_semesters[$current_semester]['name'] ?? 'Unknown' ?>
                    (<?= $all_semesters[$current_semester]['level_term'] ?? 'Unknown' ?>)
                    <?php if (isset($semester_access[$current_semester]) && !$semester_access[$current_semester]): ?>
                        <span class="badge bg-warning ms-2">Results Restricted</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        
        <!-- Display Separate Table for Each Semester -->
        <?php foreach ($all_semesters as $semester_num => $semester_info): 
            // Determine if this is current semester
            $is_current = $semester_num == $current_semester;
            $is_completed = $semester_num < $current_semester;
            $is_upcoming = $semester_num > $current_semester;
            
            // Check if student can view this semester
            $can_view = $semester_access[$semester_num] ?? false;
            
            // Get scores for this semester (only if accessible)
            $semester_data = $can_view ? ($semester_scores[$semester_num] ?? []) : [];
            $has_data = !empty($semester_data);
            $semester_gpa = $semester_gpas[$semester_num] ?? 0;
            
            $section_class = "semester-section";
            if ($is_current) {
                $section_class .= " current-semester";
            } elseif ($is_completed) {
                $section_class .= " completed";
            } elseif ($is_upcoming) {
                $section_class .= " upcoming";
            }
            
            // Add restricted class if cannot view
            if (!$can_view) {
                $section_class .= " restricted";
            }
        ?>
        <div class="card <?= $section_class ?> shadow">
            <div class="card-header semester-header position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h5 class="mb-0">
                            <i class="fa fa-book"></i> 
                            <?= $semester_info['name'] ?> (<?= $semester_info['level_term'] ?>)
                            <?php if (!$can_view): ?>
                                <i class="fa fa-lock ms-2" title="Results Restricted"></i>
                            <?php endif; ?>
                        </h5>
                    </div>
                    <div class="col-md-4 text-end">
                        <?php if ($can_view && $has_data && $semester_gpa > 0): ?>
                            <span class="badge semester-gpa">
                                Semester GPA: <?= $semester_gpa ?>
                            </span>
                        <?php elseif (!$can_view): ?>
                            <span class="badge bg-danger">Access Restricted</span>
                        <?php elseif ($is_upcoming): ?>
                            <span class="badge bg-secondary">Upcoming</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">No GPA Data</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Status Badge -->
                <span class="position-absolute top-0 end-0 m-2 badge 
                    <?= $is_current ? 'bg-warning text-dark current-semester-badge' : '' ?>
                    <?= $is_completed ? 'bg-success' : '' ?>
                    <?= $is_upcoming ? 'bg-secondary' : '' ?>
                    <?= !$can_view ? 'bg-danger' : '' ?>">
                    <?php if (!$can_view): ?>
                        <i class="fa fa-lock"></i> Restricted
                    <?php elseif ($is_current): ?>
                        <i class="fa fa-spinner"></i> Current
                    <?php elseif ($is_completed): ?>
                        <i class="fa fa-check-circle"></i> Completed
                    <?php elseif ($is_upcoming): ?>
                        <i class="fa fa-clock"></i> Upcoming
                    <?php else: ?>
                        <i class="fa fa-exclamation-circle"></i> No Data
                    <?php endif; ?>
                </span>
            </div>
            
            <div class="card-body">
                <?php if ($can_view && $has_data): ?>
                    <!-- SIMPLIFIED TABLE - Only showing Total Marks, Percentage, Grade -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Course Code</th>
                                    <th>Course Title</th>
                                    <th>Credit Hours</th>
                                    <th>Total Marks</th>
                                    <th>Percentage</th>
                                    <th>Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($semester_data as $score): 
                                    $grade_class = '';
                                    $letter_grade = $score['letter_grade'] ?? '';
                                    if (strpos($letter_grade, 'A') === 0) {
                                        $grade_class = 'grade-A';
                                    } elseif (strpos($letter_grade, 'B') === 0) {
                                        $grade_class = 'grade-B';
                                    } elseif (strpos($letter_grade, 'C') === 0) {
                                        $grade_class = 'grade-C';
                                    } elseif ($letter_grade == 'D') {
                                        $grade_class = 'grade-D';
                                    } elseif ($letter_grade == 'F') {
                                        $grade_class = 'grade-F';
                                    }
                                ?>
                                <tr>
                                    <td class="course-code"><?= htmlspecialchars($score['subject_code']) ?></td>
                                    <td><?= htmlspecialchars($score['subject']) ?></td>
                                    <td class="text-center"><?= $score['credit_hours'] ?></td>
                                    <td class="text-center fw-bold"><?= number_format($score['total_marks'] ?? 0, 1) ?></td>
                                    <td class="text-center"><?= number_format($score['percentage'] ?? 0, 1) ?>%</td>
                                    <td class="text-center">
                                        <?php if (!empty($letter_grade)): ?>
                                            <span class="badge <?= $grade_class ?>">
                                                <?= htmlspecialchars($letter_grade) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Semester GPA Summary -->
                    <?php if ($semester_gpa > 0): ?>
                    <div class="mt-3 p-3 bg-light rounded">
                        <div class="row text-center">
                            <div class="col-md-4">
                                <strong>Total Courses:</strong> 
                                <span class="badge bg-dark"><?= count($semester_data) ?></span>
                            </div>
                            <div class="col-md-4">
                                <strong>Graded Courses:</strong> 
                                <span class="badge bg-info">
                                    <?= count(array_filter($semester_data, function($score) { 
                                        return !empty($score['letter_grade']); 
                                    })) ?>
                                </span>
                            </div>
                            <div class="col-md-4">
                                <strong>Semester GPA:</strong> 
                                <span class="badge bg-primary"><?= $semester_gpa ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                <?php elseif (!$can_view): ?>
                    <!-- Restricted Access Message -->
                    <div class="text-center py-4 text-muted">
                        <i class="fa fa-lock fa-3x mb-3 text-danger"></i>
                        <h5>Results Access Restricted</h5>
                        <p class="mb-2">You cannot view the results for this semester due to outstanding fees.</p>
                        <p class="mb-0">
                            <strong>Please clear your dues to access the results.</strong>
                        </p>
                        <?php if (isset($fee_status[$semester_num])): ?>
                        <div class="mt-3">
                            <span class="badge bg-warning text-dark">
                                Due Amount: ৳<?= number_format($fee_status[$semester_num]['due_amount'], 2) ?>
                            </span>
                            <span class="badge bg-secondary ms-2">
                                Status: <?= ucfirst($fee_status[$semester_num]['payment_status']) ?>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <!-- No Data Message -->
                    <div class="text-center py-4 text-muted">
                        <i class="fa fa-clock fa-3x mb-3"></i>
                        <h5>No Grade Records Available</h5>
                        <p>Grade records for this semester will appear here once published.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        
        <?php else: ?>
            <!-- No Scores Message -->
            <div class="container mt-4">
                <div class="alert alert-info text-center">
                    <i class="fa fa-info-circle fa-3x mb-3"></i>
                    <h4>No Grade Records Found</h4>
                    <p class="mb-0">Your grade records will appear here once your teachers publish them.</p>
                    <p class="mt-2">
                        <a href="all-results.php" class="btn btn-primary">Check All Results</a>
                    </p>
                </div>
            </div>
        <?php endif; ?>
        
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>  
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(2) a").addClass('active');
            
            // Smooth scroll to current semester
            document.querySelector('.current-semester')?.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        });
    </script>
</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    } 
} else {
  header("Location: ../login.php");
  exit;
}