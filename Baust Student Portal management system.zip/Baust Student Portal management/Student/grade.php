<?php
// student/grade.php
session_start();
if (isset($_SESSION['student_id']) && isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Student') {
        include "../DB_connection.php";
        include "data/score.php";
        
        $student_id = $_SESSION['student_id'];
        
        // Get student's current level and term
        $current_level_term = getStudentCurrentLevelTerm($student_id, $conn);
        $current_level = $current_level_term['level'];
        $current_term = $current_level_term['term'];
        $current_semester = (($current_level - 1) * 2) + $current_term;
        
        // Get scores for current semester
        $current_scores = getScoresByLevelTerm($student_id, $current_level, $current_term, $conn);
        
        // Calculate current semester GPA
        $current_gpa = calculateLevelTermGPA($current_scores);
        
        // Redirect to all-results.php which shows complete grade summary
        header("Location: all-results.php");
        exit;
        
    } else {
        header("Location: ../login.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>