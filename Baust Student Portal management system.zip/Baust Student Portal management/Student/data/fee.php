<?php
// data/fee.php

// Function to check if student can view semester results
if (!function_exists('canViewSemesterResults')) {
    function canViewSemesterResults($student_id, $semester, $conn) {
        try {
            $sql = "SELECT payment_status, due_amount 
                    FROM student_fees 
                    WHERE student_id = ? AND semester = ? 
                    ORDER BY academic_year DESC 
                    LIMIT 1";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $semester]);
            $fee_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // If no fee record found, allow access 
            if (!$fee_data) {
                return true;
            }
            
            // Allow access if: fully paid OR due amount less than 3000
            if ($fee_data['payment_status'] == 'paid' || 
                (floatval($fee_data['due_amount']) <= 3000 && $fee_data['payment_status'] == 'partial')) {
                return true;
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log("canViewSemesterResults Error: " . $e->getMessage());
            return false; // Deny access on error for security
        }
    }
}

// Function to get student's fee status for all semesters
if (!function_exists('getStudentFeeStatus')) {
    function getStudentFeeStatus($student_id, $conn) {
        try {
            $sql = "SELECT semester, payment_status, due_amount, paid_amount
                    FROM student_fees 
                    WHERE student_id = ? 
                    ORDER BY semester";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id]);
            $fee_status = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $result = [];
            foreach ($fee_status as $fee) {
                $result[$fee['semester']] = [
                    'payment_status' => $fee['payment_status'],
                    'due_amount' => floatval($fee['due_amount']),
                    'paid_amount' => floatval($fee['paid_amount']),
                    'can_view' => ($fee['payment_status'] == 'paid' || 
                                 (floatval($fee['due_amount']) <= 3000 && $fee['payment_status'] == 'partial'))
                ];
            }
            
            return $result;
            
        } catch (PDOException $e) {
            error_log("getStudentFeeStatus Error: " . $e->getMessage());
            return [];
        }
    }
}

// Function to check if student can progress to next semester
if (!function_exists('canProgressToNextSemester')) {
    function canProgressToNextSemester($student_id, $current_semester, $conn) {
        try {
            $sql = "SELECT payment_status, due_amount 
                    FROM student_fees 
                    WHERE student_id = ? AND semester = ? 
                    ORDER BY academic_year DESC 
                    LIMIT 1";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $current_semester]);
            $fee_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // If no fee record, allow progression (for backward compatibility)
            if (!$fee_data) {
                return true;
            }
            
            // Allow progression only if current semester fees are fully paid
            return ($fee_data['payment_status'] == 'paid');
            
        } catch (PDOException $e) {
            error_log("canProgressToNextSemester Error: " . $e->getMessage());
            return false;
        }
    }
}
?>