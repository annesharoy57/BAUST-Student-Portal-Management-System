<?php
// data/score.php - CORRECTED CGPA CALCULATION

// Function to get student's current level and term
if (!function_exists('getStudentCurrentLevelTerm')) {
    function getStudentCurrentLevelTerm($student_id, $conn) {
        try {
            $sql = "SELECT s.grade, g.level, g.term 
                    FROM students s 
                    LEFT JOIN grades g ON s.grade = g.grade_id 
                    WHERE s.student_id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($data && !empty($data['level']) && !empty($data['term'])) {
                $level = intval($data['level']);
                $term = ($data['term'] == 'I' || $data['term'] == '1') ? 1 : 2;
                return ['level' => $level, 'term' => $term];
            }

            $sql = "SELECT g.level, g.term 
                    FROM student_score ss
                    LEFT JOIN subjects s ON ss.subject_id = s.subject_id
                    LEFT JOIN grades g ON s.grade = g.grade_id
                    WHERE ss.student_id = ? AND g.level IS NOT NULL AND g.term IS NOT NULL
                    ORDER BY CAST(g.level AS UNSIGNED) DESC, 
                             CASE g.term WHEN 'I' THEN 1 WHEN 'II' THEN 2 ELSE 3 END DESC 
                    LIMIT 1";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id]);
            $score_data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($score_data && !empty($score_data['level']) && !empty($score_data['term'])) {
                $level = intval($score_data['level']);
                $term = ($score_data['term'] == 'I' || $score_data['term'] == '1') ? 1 : 2;
                return ['level' => $level, 'term' => $term];
            }

            return ['level' => 1, 'term' => 1];

        } catch (PDOException $e) {
            return ['level' => 1, 'term' => 1];
        }
    }
}

// Function to get student grade display name
if (!function_exists('getStudentGradeDisplay')) {
    function getStudentGradeDisplay($student_id, $conn) {
        try {
            $level_term = getStudentCurrentLevelTerm($student_id, $conn);
            $level = $level_term['level'];
            $term = $level_term['term'];
            $term_roman = ($term == 1) ? 'I' : 'II';
            return $level . '-' . $term_roman;
        } catch (PDOException $e) {
            return "Unknown";
        }
    }
}

// Function to get ALL scores with complete details
if (!function_exists('getAllStudentScoresWithDetails')) {
    function getAllStudentScoresWithDetails($student_id, $conn) {
        try {
            $sql = "SELECT ss.*, 
                           s.subject_code, s.subject, s.credit_hours, s.course_type,
                           g.level, g.term, g.grade_id,
                           t.fname as teacher_fname, t.lname as teacher_lname
                    FROM student_score ss
                    LEFT JOIN subjects s ON ss.subject_id = s.subject_id
                    LEFT JOIN grades g ON s.grade = g.grade_id
                    LEFT JOIN teachers t ON ss.teacher_id = t.teacher_id
                    WHERE ss.student_id = ?
                    ORDER BY CAST(g.level AS UNSIGNED), 
                             CASE g.term WHEN 'I' THEN 1 WHEN 'II' THEN 2 ELSE 3 END, 
                             ss.year, ss.semester, s.subject_code";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}

// Function to calculate CGPA for all courses - CORRECTED VERSION (Average of Semester GPAs)
if (!function_exists('calculateStudentCGPA')) {
    function calculateStudentCGPA($scores) {
        if (empty($scores)) {
            return [
                'cgpa' => 0, 
                'total_credits' => 0, 
                'completed_courses' => 0,
                'completed_semesters' => 0
            ];
        }
        
        // Group scores by semester (level-term combination)
        $semester_scores = [];
        foreach ($scores as $score) {
            $level = intval($score['level'] ?? 1);
            $term_str = $score['term'] ?? 'I';
            $term = ($term_str == 'I' || $term_str == '1') ? 1 : 2;
            
            $semester_key = $level . '-' . $term;
            if (!isset($semester_scores[$semester_key])) {
                $semester_scores[$semester_key] = [];
            }
            $semester_scores[$semester_key][] = $score;
        }
        
        // Calculate GPA for each semester
        $semester_gpas = [];
        $total_credit_hours = 0;
        $completed_courses = 0;
        
        foreach ($semester_scores as $semester_key => $semester_courses) {
            $semester_credits = 0;
            $semester_points = 0;
            $semester_has_grades = false;
            
            foreach ($semester_courses as $course) {
                $credit_hours = floatval($course['credit_hours'] ?? 0);
                $grade_point = floatval($course['grade_point'] ?? 0);
                
                // For total statistics
                if ($grade_point > 0) {
                    $total_credit_hours += $credit_hours;
                    $completed_courses++;
                }
                
                // For semester GPA calculation
                if ($grade_point > 0) {
                    $semester_credits += $credit_hours;
                    $semester_points += ($credit_hours * $grade_point);
                    $semester_has_grades = true;
                }
            }
            
            // Calculate semester GPA only if it has graded courses
            if ($semester_has_grades && $semester_credits > 0) {
                $semester_gpa = $semester_points / $semester_credits;
                $semester_gpas[] = $semester_gpa;
            }
        }
        
        // Calculate cumulative CGPA as average of all semester GPAs
        $cumulative_cgpa = 0;
        $completed_semesters = count($semester_gpas);
        
        if ($completed_semesters > 0) {
            $cumulative_cgpa = array_sum($semester_gpas) / $completed_semesters;
        }
        
        return [
            'cgpa' => $cumulative_cgpa,
            'total_credits' => $total_credit_hours,
            'completed_courses' => $completed_courses,
            'completed_semesters' => $completed_semesters
        ];
    }
}

// Function to get grade letter and points based on percentage
if (!function_exists('calculateGrade')) {
    function calculateGrade($percentage) {
        $percentage = floatval($percentage);
        
        if ($percentage >= 80) return ['letter' => 'A+', 'point' => 4.00];
        if ($percentage >= 75) return ['letter' => 'A', 'point' => 3.75];
        if ($percentage >= 70) return ['letter' => 'A-', 'point' => 3.50];
        if ($percentage >= 65) return ['letter' => 'B+', 'point' => 3.25];
        if ($percentage >= 60) return ['letter' => 'B', 'point' => 3.00];
        if ($percentage >= 55) return ['letter' => 'B-', 'point' => 2.75];
        if ($percentage >= 50) return ['letter' => 'C+', 'point' => 2.50];
        if ($percentage >= 45) return ['letter' => 'C', 'point' => 2.25];
        if ($percentage >= 40) return ['letter' => 'D', 'point' => 2.00];
        return ['letter' => 'F', 'point' => 0.00];
    }
}

// Function to get scores by level and term
if (!function_exists('getScoresByLevelTerm')) {
    function getScoresByLevelTerm($student_id, $level, $term, $conn) {
        try {
            $term_roman = ($term == 1) ? 'I' : 'II';
            
            $sql = "SELECT ss.*, 
                           s.subject_code, s.subject, s.credit_hours, s.course_type,
                           g.level, g.term,
                           t.fname as teacher_fname, t.lname as teacher_lname
                    FROM student_score ss
                    LEFT JOIN subjects s ON ss.subject_id = s.subject_id
                    LEFT JOIN grades g ON s.grade = g.grade_id
                    LEFT JOIN teachers t ON ss.teacher_id = t.teacher_id
                    WHERE ss.student_id = ? AND g.level = ? AND g.term = ?
                    ORDER BY s.subject_code";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $level, $term_roman]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}

// Function to calculate GPA for specific level and term
if (!function_exists('calculateLevelTermGPA')) {
    function calculateLevelTermGPA($scores) {
        $total_credit_hours = 0;
        $total_grade_points = 0;
        
        foreach ($scores as $score) {
            $credit_hours = floatval($score['credit_hours'] ?? 0);
            $grade_point = floatval($score['grade_point'] ?? 0);
            
            if ($grade_point > 0) {
                $total_credit_hours += $credit_hours;
                $total_grade_points += ($credit_hours * $grade_point);
            }
        }
        
        if ($total_credit_hours > 0) {
            return $total_grade_points / $total_credit_hours;
        }
        
        return 0;
    }
}

// Function to get student's academic progression
if (!function_exists('getStudentAcademicProgression')) {
    function getStudentAcademicProgression($student_id, $conn) {
        $progression = [];
        
        // Define all possible level-term combinations
        $all_level_terms = [
            ['level' => 1, 'term' => 1],
            ['level' => 1, 'term' => 2],
            ['level' => 2, 'term' => 1],
            ['level' => 2, 'term' => 2],
            ['level' => 3, 'term' => 1],
            ['level' => 3, 'term' => 2],
            ['level' => 4, 'term' => 1],
            ['level' => 4, 'term' => 2]
        ];
        
        $current_level_term = getStudentCurrentLevelTerm($student_id, $conn);
        $current_semester = (($current_level_term['level'] - 1) * 2) + $current_level_term['term'];
        
        foreach ($all_level_terms as $index => $level_term) {
            $semester_num = $index + 1;
            $scores = getScoresByLevelTerm($student_id, $level_term['level'], $level_term['term'], $conn);
            $gpa = calculateLevelTermGPA($scores);
            
            $status = 'upcoming';
            if ($semester_num < $current_semester) {
                $status = 'completed';
            } elseif ($semester_num == $current_semester) {
                $status = 'current';
            }
            
            $progression[$semester_num] = [
                'level' => $level_term['level'],
                'term' => $level_term['term'],
                'semester' => $semester_num,
                'status' => $status,
                'has_scores' => !empty($scores),
                'gpa' => number_format($gpa, 2),
                'courses' => $scores
            ];
        }
        
        return $progression;
    }
}

// Function to get total completed credits
if (!function_exists('getTotalCompletedCredits')) {
    function getTotalCompletedCredits($scores) {
        $total_credits = 0;
        
        foreach ($scores as $score) {
            $credit_hours = floatval($score['credit_hours'] ?? 0);
            $grade_point = floatval($score['grade_point'] ?? 0);
            
            if ($grade_point > 0) {
                $total_credits += $credit_hours;
            }
        }
        
        return $total_credits;
    }
}
?>