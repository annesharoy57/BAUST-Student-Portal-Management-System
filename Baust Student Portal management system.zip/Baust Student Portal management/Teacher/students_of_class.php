<?php 
session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
       include "../DB_connection.php";
       include "data/student.php";
       include "data/grade.php";
       include "data/class.php";
       include "data/section.php";
       
       if (!isset($_GET['class_id'])) {
           header("Location: students.php");
           exit;
       }
       
       $class_id = $_GET['class_id'];
       $students = getAllStudents($conn);
       $class = getClassById($class_id, $conn);

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher - Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
    include "inc/navbar.php";
    
    if ($students != 0 && $class != 0) {
        $check = 0;
        $i = 0;
        
        // CORRECTED: Using getSectionById (not getSectioById)
        $class_grade = getGradeById($class['grade'], $conn);
        $class_section = getSectionById($class['section'], $conn);
        
        // Get class name for display
        $class_name = '';
        if ($class_grade != 0 && $class_section != 0) {
            $class_name = $class_grade['level'] . '-' . $class_grade['term'] . ' ' . $class_section['section'];
        } else if ($class_grade != 0) {
            $class_name = $class_grade['level'] . '-' . $class_grade['term'] . ' (No section)';
        } else {
            $class_name = 'Class ' . $class_id;
        }
    ?>
     
    <div class="container mt-5">
        <h3>Students of <?=$class_name?></h3>
        <a href="students.php" class="btn btn-dark mb-3">Back to Classes</a>
        
        <div class="table-responsive">
            <table class="table table-bordered mt-3 n-table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Grade</th>
                    </tr>
                </thead>
                <tbody>  
                <?php 
                foreach ($students as $student) { 
                    // Check if student belongs to this class (same grade and section)
                    if ($class_grade != 0 && $class_section != 0 && 
                        $class_grade['grade_id'] == $student['grade'] && 
                        $class_section['section_id'] == $student['section']) { 
                        $i++; 
                        $check++;
                ?>          
                    <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?=$student['student_id']?></td>
                        <td>
                            <a href="student-grade.php?student_id=<?=$student['student_id']?>">
                                <?=$student['fname']?>
                            </a>
                        </td>
                        <td><?=$student['lname']?></td>
                        <td><?=$student['username']?></td>
                        <td>
                            <?php 
                                $student_grade = getGradeById($student['grade'], $conn);
                                if ($student_grade != 0) {
                                    echo $student_grade['level'] . '-' . $student_grade['term'];
                                } else {
                                    echo 'N/A';
                                }
                            ?>
                        </td>
                    </tr>
                <?php 
                    } 
                } 
                
                if ($check == 0) {
                ?>
                    <tr>
                        <td colspan="6" class="text-center">No students found in this class</td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php 
    } else { 
    ?>
        <div class="container mt-5">
            <div class="alert alert-info .w-450 m-5" role="alert">
                No students found or invalid class!
            </div>
            <a href="students.php" class="btn btn-dark">Back to Classes</a>
        </div>
    <?php 
    } 
    ?>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 

  } else {
    header("Location: ../login.php");
    exit;
  } 
} else {
    header("Location: ../login.php");
    exit;
} 
?>