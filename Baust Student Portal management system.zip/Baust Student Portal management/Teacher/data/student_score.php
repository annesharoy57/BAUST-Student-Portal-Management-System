<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Only allow logged-in teachers
if (!isset($_SESSION['teacher_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'Teacher') {
    header("Location: ../login.php");
    exit;
}

include_once "../DB_connection.php";
include_once "data/student.php";
include_once "data/grade.php";
include_once "data/section.php";
include_once "data/setting.php";
include_once "data/subject.php";
include_once "data/teacher.php";
include_once "data/grades_score.php"; // Include the new file with grade functions

// Check if student_id is provided
if (!isset($_GET['student_id'])) {
    header("Location: students.php");
    exit;
}

$student_id = $_GET['student_id'];
$student = getStudentById($student_id, $conn);
if (!$student) {
    header("Location: students.php");
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher = getTeacherById($teacher_id, $conn);
$setting = getSetting($conn);

// Teacher's assigned subjects
$teacher_subjects = [];
if (!empty($teacher['subjects'])) {
    $teacher_subjects = array_filter(array_map('trim', explode(',', $teacher['subjects'])));
}

// Subjects for student's grade
$subjects = getSubjectByGrade($student['grade'], $conn);

// Find common subjects (student's subjects that teacher teaches)
$common_subjects = [];
if ($subjects && !empty($teacher_subjects)) {
    foreach ($subjects as $subject) {
        if (in_array((string)$subject['subject_id'], $teacher_subjects) ||
            in_array($subject['subject_id'], $teacher_subjects)) {
            $common_subjects[] = $subject;
        }
    }
}

$ssubject_id = 0;
$student_score = 0;
if (isset($_POST['ssubject_id'])) {
    $ssubject_id = $_POST['ssubject_id'];
    $student_score = getScoreById($student_id, $teacher_id, $ssubject_id, 
                                  $setting['current_semester'], $setting['current_year'], $conn);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher - Student Grade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../logo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        .grade-table th {background-color: #343a40;color: white;text-align:center;}
        .grade-table td {vertical-align: middle;}
        .results-cell {min-width: 200px;}
        .score-input {width: 80px;text-align:center;}
        .total-score {font-weight: bold;font-size: 1.1em;}
        .component-label {font-size: 0.8em;color: #666;margin-bottom: 2px;}
        .marks-row {margin-bottom: 8px;padding: 4px;border-bottom: 1px solid #eee;}
        .badge {font-size: 0.9em;}
    </style>
</head>
<body>
    <?php include "inc/navbar.php"; ?>

    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="text-center mb-0">Student Grade Management</h4>
            </div>
            <div class="card-body">

                <!-- Alert Messages -->
                <?php if (isset($_GET['error'])) { ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($_GET['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php } ?>

                <?php if (isset($_GET['success'])) { ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php } ?>

                <!-- Student Info -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>Student Information</h5>
                        <p><strong>ID:</strong> <?= htmlspecialchars($student['student_id']) ?></p>
                        <p><strong>Name:</strong> <?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></p>
                        <?php $grade = getGradeById($student['grade'], $conn); ?>
                        <?php $section = getSectionById($student['section'], $conn); ?>
                        <p><strong>Grade:</strong> <?= $grade ? htmlspecialchars($grade['level'] . '-' . $grade['term']) : 'N/A' ?></p>
                        <p><strong>Section:</strong> <?= $section ? 'Section ' . htmlspecialchars($section['section']) : 'Section ID: ' . htmlspecialchars($student['section']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h5>Academic Information</h5>
                        <p><strong>Year:</strong> <?= htmlspecialchars($setting['current_year']) ?></p>
                        <p><strong>Semester:</strong> <?= htmlspecialchars($setting['current_semester']) ?></p>
                        <p><strong>Institute:</strong> <?= htmlspecialchars($setting['university_name'] ?? 'N/A') ?></p>
                    </div>
                </div>

                <!-- Subject Selection -->
                <form method="post" class="mb-4">
                    <div class="mb-3">
                        <label class="form-label"><strong>Select Common Course:</strong></label>
                        <select class="form-control" name="ssubject_id" required>
                            <option value="">-- Select Course --</option>
                            <?php 
                            if (!empty($common_subjects)) {
                                foreach($common_subjects as $subject) {
                                    $selected = ($ssubject_id == $subject['subject_id']) ? 'selected' : '';
                                    echo "<option value='{$subject['subject_id']}' {$selected}>
                                        {$subject['subject_code']} - {$subject['subject']} (" . ucfirst($subject['course_type']) . ")
                                    </option>";
                                }
                            } else {
                                echo '<option value="">No common courses found</option>';
                            }
                            ?>
                        </select>
                        
                        <?php if (empty($common_subjects)) { ?>
                        <div class="alert alert-warning mt-2">
                            <strong>No Common Courses Found!</strong><br>
                            This student is not enrolled in any courses that you teach.
                        </div>
                        <?php } ?>
                    </div>
                    
                    <?php if (!empty($common_subjects)) { ?>
                    <button type="submit" class="btn btn-primary">Load Grade Form</button>
                    <?php } ?>
                </form>

                <?php if ($ssubject_id && !empty($common_subjects)) : 
                    $selected_subject = null;
                    foreach($common_subjects as $subject){
                        if($subject['subject_id'] == $ssubject_id){ 
                            $selected_subject = $subject; 
                            break; 
                        }
                    }
                    if ($selected_subject) :
                    $existing_marks = getDetailedMarks($student_id, $ssubject_id, $setting['current_semester'], $setting['current_year'], $conn);
                ?>
                
                <form method="post" action="req/save_score.php">
                    <h5>Marks Entry: <?= htmlspecialchars($selected_subject['subject_code']) ?> - <?= htmlspecialchars($selected_subject['subject']) ?></h5>
                    <p class="text-muted">
                        Course Type: <strong><?= ucfirst($selected_subject['course_type']) ?></strong> | 
                        Credit Hours: <strong><?= htmlspecialchars($selected_subject['credit_hours'] ?? '3.00') ?></strong>
                    </p>

                    <?php if ($selected_subject['course_type'] == 'theory') : ?>
                        <!-- Theory Course Marks -->
                        <div class="card">
                            <div class="card-body">
                                <h6>Theory Course Components (Total: 300 marks)</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Class Tests (Best 2 out of 3)</div>
                                            <div class="row g-2">
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct1]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="10" step="1" placeholder="CT1" 
                                                           value="<?= isset($existing_marks['ct1']) ? htmlspecialchars($existing_marks['ct1']) : '' ?>">
                                                    <small class="text-muted">CT 1 (10)</small>
                                                </div>
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct2]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="10" step="1" placeholder="CT2"
                                                           value="<?= isset($existing_marks['ct2']) ? htmlspecialchars($existing_marks['ct2']) : '' ?>">
                                                    <small class="text-muted">CT 2 (10)</small>
                                                </div>
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct3]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="10" step="1" placeholder="CT3"
                                                           value="<?= isset($existing_marks['ct3']) ? htmlspecialchars($existing_marks['ct3']) : '' ?>">
                                                    <small class="text-muted">CT 3 (10)</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Assignment</div>
                                            <input type="number" name="marks[assignment]" class="form-control form-control-sm score-input" 
                                                   min="0" max="15" step="1" placeholder="0-15"
                                                   value="<?= isset($existing_marks['assignment']) ? htmlspecialchars($existing_marks['assignment']) : '' ?>">
                                            <small class="text-muted">Max: 15 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Mid Term</div>
                                            <input type="number" name="marks[mid_term]" class="form-control form-control-sm score-input" 
                                                   min="0" max="45" step="1" placeholder="0-45"
                                                   value="<?= isset($existing_marks['mid_term']) ? htmlspecialchars($existing_marks['mid_term']) : '' ?>">
                                            <small class="text-muted">Max: 45 marks</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Attendance</div>
                                            <input type="number" name="marks[attendance]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['attendance']) ? htmlspecialchars($existing_marks['attendance']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Final Exam</div>
                                            <input type="number" name="marks[final_exam]" class="form-control form-control-sm score-input" 
                                                   min="0" max="180" step="1" placeholder="0-180"
                                                   value="<?= isset($existing_marks['final_exam']) ? htmlspecialchars($existing_marks['final_exam']) : '' ?>">
                                            <small class="text-muted">Max: 180 marks</small>
                                        </div>
                                        
                                        <!-- Results Display -->
                                        <div class="marks-row bg-light p-3 rounded">
                                            <div class="row text-center">
                                                <div class="col-4">
                                                    <strong>Total</strong><br>
                                                    <span id="theoryTotalDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['total_marks']) ? number_format($existing_marks['total_marks'], 2) : '0.00' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Percentage</strong><br>
                                                    <span id="theoryPercentageDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['percentage']) ? number_format($existing_marks['percentage'], 2) . '%' : '0.00%' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Grade</strong><br>
                                                    <span id="theoryGradeDisplay" class="fw-bold fs-5 badge 
                                                        <?php 
                                                        if(isset($existing_marks['letter_grade'])) {
                                                            if($existing_marks['letter_grade'] == 'F') echo 'bg-danger';
                                                            elseif(in_array($existing_marks['letter_grade'], ['A+', 'A', 'A-'])) echo 'bg-success';
                                                            else echo 'bg-warning';
                                                        } else { 
                                                            echo 'bg-secondary'; 
                                                        } 
                                                        ?>">
                                                        <?= isset($existing_marks['letter_grade']) ? htmlspecialchars($existing_marks['letter_grade']) : 'N/A' ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Sessional Course Marks -->
                        <div class="card">
                            <div class="card-body">
                                <h6>Sessional Course Components (Total: 100 marks)</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Lab Attendance</div>
                                            <input type="number" name="marks[lab_attendance]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_attendance']) ? htmlspecialchars($existing_marks['lab_attendance']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Report</div>
                                            <input type="number" name="marks[lab_report]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['lab_report']) ? htmlspecialchars($existing_marks['lab_report']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Mid</div>
                                            <input type="number" name="marks[lab_mid]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['lab_mid']) ? htmlspecialchars($existing_marks['lab_mid']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Lab Final</div>
                                            <input type="number" name="marks[lab_final]" class="form-control form-control-sm score-input" 
                                                   min="0" max="30" step="1" placeholder="0-30"
                                                   value="<?= isset($existing_marks['lab_final']) ? htmlspecialchars($existing_marks['lab_final']) : '' ?>">
                                            <small class="text-muted">Max: 30 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Viva</div>
                                            <input type="number" name="marks[lab_viva]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_viva']) ? htmlspecialchars($existing_marks['lab_viva']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Quiz</div>
                                            <input type="number" name="marks[lab_quiz]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_quiz']) ? htmlspecialchars($existing_marks['lab_quiz']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <!-- Results Display -->
                                        <div class="marks-row bg-light p-3 rounded">
                                            <div class="row text-center">
                                                <div class="col-4">
                                                    <strong>Total</strong><br>
                                                    <span id="sessionalTotalDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['total_marks']) ? number_format($existing_marks['total_marks'], 2) : '0.00' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Percentage</strong><br>
                                                    <span id="sessionalPercentageDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['percentage']) ? number_format($existing_marks['percentage'], 2) . '%' : '0.00%' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Grade</strong><br>
                                                    <span id="sessionalGradeDisplay" class="fw-bold fs-5 badge 
                                                        <?php 
                                                        if(isset($existing_marks['letter_grade'])) {
                                                            if($existing_marks['letter_grade'] == 'F') echo 'bg-danger';
                                                            elseif(in_array($existing_marks['letter_grade'], ['A+', 'A', 'A-'])) echo 'bg-success';
                                                            else echo 'bg-warning';
                                                        } else { 
                                                            echo 'bg-secondary'; 
                                                        } 
                                                        ?>">
                                                        <?= isset($existing_marks['letter_grade']) ? htmlspecialchars($existing_marks['letter_grade']) : 'N/A' ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <input type="hidden" name="student_id" value="<?= htmlspecialchars($student_id) ?>">
                    <input type="hidden" name="subject_id" value="<?= htmlspecialchars($ssubject_id) ?>">
                    <input type="hidden" name="current_semester" value="<?= htmlspecialchars($setting['current_semester']) ?>">
                    <input type="hidden" name="current_year" value="<?= htmlspecialchars($setting['current_year']) ?>">
                    <input type="hidden" name="course_type" value="<?= htmlspecialchars($selected_subject['course_type']) ?>">
                
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Save Detailed Marks
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="calculateTotals()">
                            <i class="fas fa-calculator"></i> Calculate
                        </button>
                        <a href="student-grade.php?student_id=<?= htmlspecialchars($student_id) ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-refresh"></i> Refresh
                        </a>
                    </div>
                </form>  
                <?php 
                    else:
                        echo '<div class="alert alert-warning">Selected course not found in common courses.</div>';
                    endif;
                endif; 
                ?>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(4) a").addClass('active');
            calculateTotals(); // Initial calculation
            
            // Auto-calculate when inputs change
            $('.score-input').on('input', function() {
                calculateTotals();
            });
        });

        function calculateBestTwoCT() {
            let ct1 = parseFloat($('input[name="marks[ct1]"]').val()) || 0;
            let ct2 = parseFloat($('input[name="marks[ct2]"]').val()) || 0;
            let ct3 = parseFloat($('input[name="marks[ct3]"]').val()) || 0;
            
            let cts = [ct1, ct2, ct3].filter(val => val > 0);
            if (cts.length < 2) return cts.reduce((a, b) => a + b, 0);
            
            cts.sort((a, b) => b - a);
            return cts[0] + cts[1];
        }

        function calculateTheoryTotal() {
            let bestTwoCT = calculateBestTwoCT();
            let assignment = parseFloat($('input[name="marks[assignment]"]').val()) || 0;
            let midTerm = parseFloat($('input[name="marks[mid_term]"]').val()) || 0;
            let attendance = parseFloat($('input[name="marks[attendance]"]').val()) || 0;
            let finalExam = parseFloat($('input[name="marks[final_exam]"]').val()) || 0;
            
            let total = bestTwoCT + assignment + midTerm + attendance + finalExam;
            let percentage = (total / 300) * 100;
            let grade = calculateGrade(percentage);
            
            $('#theoryTotalDisplay').text(total.toFixed(2));
            $('#theoryPercentageDisplay').text(percentage.toFixed(2) + '%');
            $('#theoryGradeDisplay').text(grade).removeClass('bg-secondary bg-success bg-warning bg-danger')
                .addClass(getGradeBadgeClass(grade));
        }

        function calculateSessionalTotal() {
            let labAttendance = parseFloat($('input[name="marks[lab_attendance]"]').val()) || 0;
            let labReport = parseFloat($('input[name="marks[lab_report]"]').val()) || 0;
            let labMid = parseFloat($('input[name="marks[lab_mid]"]').val()) || 0;
            let labFinal = parseFloat($('input[name="marks[lab_final]"]').val()) || 0;
            let labViva = parseFloat($('input[name="marks[lab_viva]"]').val()) || 0;
            let labQuiz = parseFloat($('input[name="marks[lab_quiz]"]').val()) || 0;
            
            let total = labAttendance + labReport + labMid + labFinal + labViva + labQuiz;
            let percentage = (total / 100) * 100;
            let grade = calculateGrade(percentage);
            
            $('#sessionalTotalDisplay').text(total.toFixed(2));
            $('#sessionalPercentageDisplay').text(percentage.toFixed(2) + '%');
            $('#sessionalGradeDisplay').text(grade).removeClass('bg-secondary bg-success bg-warning bg-danger')
                .addClass(getGradeBadgeClass(grade));
        }

        function calculateTotals() {
            <?php if ($ssubject_id && isset($selected_subject)) { ?>
                if('<?= $selected_subject['course_type'] ?>' == 'theory') {
                    calculateTheoryTotal();
                } else {
                    calculateSessionalTotal();
                }
            <?php } ?>
        }

        function calculateGrade(percentage) {
            if (percentage >= 80) return 'A+';
            if (percentage >= 75) return 'A';
            if (percentage >= 70) return 'A-';
            if (percentage >= 65) return 'B+';
            if (percentage >= 60) return 'B';
            if (percentage >= 55) return 'B-';
            if (percentage >= 50) return 'C+';
            if (percentage >= 45) return 'C';
            if (percentage >= 40) return 'D';
            return 'F';
        }

        function getGradeBadgeClass(grade) {
            if (grade === 'F') return 'bg-danger';
            if (['A+', 'A', 'A-'].includes(grade)) return 'bg-success';
            return 'bg-warning';
        }
    </script>
</body>
</html>