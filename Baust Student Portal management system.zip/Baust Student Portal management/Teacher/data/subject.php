<?php
// Check if functions already exist before declaring them
if (!function_exists('getAllStudents')) {
    function getAllStudents($conn) {
        $sql = "SELECT * FROM students";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $students = $stmt->fetchAll();
            return $students;
        } else {
            return 0;
        }
    }
}

if (!function_exists('getStudentById')) {
    function getStudentById($id, $conn) {
        $sql = "SELECT * FROM students WHERE student_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);

        if ($stmt->rowCount() == 1) {
            $student = $stmt->fetch();
            return $student;
        } else {
            return 0;
        }
    }
}

// ... keep all your other functions but remove the Subject\\ prefix from function_exists checks

if (!function_exists('getSubjectById')) {
    function getSubjectById($subject_id, $conn) {
        $sql = "SELECT * FROM subjects WHERE subject_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$subject_id]);
        
        if ($stmt->rowCount() == 1) {
            return $stmt->fetch();
        } else {
            return 0;
        }
    }
}

if (!function_exists('getSectionById')) {
    function getSectionById($section_id, $conn) {
        $sql = "SELECT * FROM section WHERE section_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$section_id]);
        
        if ($stmt->rowCount() == 1) {
            return $stmt->fetch();
        } else {
            return 0;
        }
    }
}

?>