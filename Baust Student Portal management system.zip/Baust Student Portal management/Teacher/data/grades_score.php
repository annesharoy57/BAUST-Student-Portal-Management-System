<?php
// data/grades_score.php

if (!function_exists('saveStudentGrades')) {
    function saveStudentGrades($student_id, $subject_id, $teacher_id, $semester, $year, $course_type, $marks, $total_marks, $percentage, $letter_grade, $conn) {
        try {
            // Validate inputs
            if (empty($student_id) || empty($subject_id) || empty($teacher_id)) {
                throw new Exception("Required fields are missing");
            }
            
            // Check if student_score table exists
            if (!checkTableExists('student_score', $conn)) {
                throw new Exception("Student scores table not found");
            }
            
            $grade_point = getGradePoint($letter_grade);
            $credit_hours = 3.00; // Default credit hours
            
            // Check if record exists
            $check_sql = "SELECT `id` FROM `student_score` 
                          WHERE `student_id` = ? AND `subject_id` = ? AND `semester` = ? AND `year` = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([$student_id, $subject_id, $semester, $year]);
            $existing = $check_stmt->fetch();
            
            if ($existing) {
                // Update existing record
                $sql = "UPDATE `student_score` 
                        SET `ct1` = ?, `ct2` = ?, `ct3` = ?, `assignment` = ?, `mid_term` = ?, 
                            `attendance` = ?, `final_exam` = ?, `total_marks` = ?, `percentage` = ?, 
                            `letter_grade` = ?, `grade_point` = ?, `teacher_id` = ?, `credit_hours` = ?,
                            `results` = ?
                        WHERE `student_id` = ? AND `subject_id` = ? AND `semester` = ? AND `year` = ?";
                $stmt = $conn->prepare($sql);
                $success = $stmt->execute([
                    $marks['ct1'] ?? 0, $marks['ct2'] ?? 0, $marks['ct3'] ?? 0,
                    $marks['assignment'] ?? 0, $marks['mid_term'] ?? 0, 
                    $marks['attendance'] ?? 0, $marks['final_exam'] ?? 0,
                    $total_marks, $percentage, $letter_grade, $grade_point, $teacher_id, $credit_hours,
                    "Marks saved for " . date('Y-m-d H:i:s'),
                    $student_id, $subject_id, $semester, $year
                ]);
            } else {
                // Insert new record
                $sql = "INSERT INTO `student_score` 
                        (`student_id`, `subject_id`, `teacher_id`, `semester`, `year`,
                         `ct1`, `ct2`, `ct3`, `assignment`, `mid_term`, `attendance`, `final_exam`,
                         `total_marks`, `percentage`, `letter_grade`, `grade_point`, `credit_hours`, `results`) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $success = $stmt->execute([
                    $student_id, $subject_id, $teacher_id, $semester, $year,
                    $marks['ct1'] ?? 0, $marks['ct2'] ?? 0, $marks['ct3'] ?? 0,
                    $marks['assignment'] ?? 0, $marks['mid_term'] ?? 0, 
                    $marks['attendance'] ?? 0, $marks['final_exam'] ?? 0,
                    $total_marks, $percentage, $letter_grade, $grade_point, $credit_hours,
                    "Marks saved for " . date('Y-m-d H:i:s')
                ]);
            }
            
            error_log("Save operation: " . ($success ? "SUCCESS" : "FAILED"));
            if (!$success) {
                $errorInfo = $stmt->errorInfo();
                error_log("PDO Error: " . print_r($errorInfo, true));
            }
            
            return $success;
            
        } catch (PDOException $e) {
            error_log("saveStudentGrades PDO Error: " . $e->getMessage());
            return false;
        } catch (Exception $e) {
            error_log("saveStudentGrades Error: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getStudentGrades')) {
    function getStudentGrades($student_id, $semester, $year, $conn) {
        try {
            if (!checkTableExists('student_score', $conn)) {
                return [];
            }
            
            $sql = "SELECT ss.*, s.subject_code, s.subject, s.credit_hours,
                           t.fname as teacher_fname, t.lname as teacher_lname
                    FROM `student_score` ss
                    JOIN `subjects` s ON ss.subject_id = s.subject_id
                    JOIN `teachers` t ON ss.teacher_id = t.teacher_id
                    WHERE ss.student_id = ? AND ss.semester = ? AND ss.year = ?
                    ORDER BY s.subject_code";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $semester, $year]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("getStudentGrades Error: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getDetailedMarks')) {
    function getDetailedMarks($student_id, $subject_id, $semester, $year, $conn) {
        try {
            if (!checkTableExists('student_score', $conn)) {
                return [];
            }
            
            $sql = "SELECT * FROM `student_score` 
                    WHERE `student_id` = ? AND `subject_id` = ? 
                    AND `semester` = ? AND `year` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $subject_id, $semester, $year]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result ? $result : [];
        } catch (PDOException $e) {
            error_log("getDetailedMarks Error: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getScoreById')) {
    function getScoreById($student_id, $teacher_id, $subject_id, $semester, $year, $conn) {
        try {
            if (!checkTableExists('student_score', $conn)) {
                return 0;
            }
            
            $sql = "SELECT * FROM `student_score` 
                    WHERE `student_id` = ? AND `teacher_id` = ? AND `subject_id` = ? 
                    AND `semester` = ? AND `year` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id, $teacher_id, $subject_id, $semester, $year]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result ? $result : 0;
        } catch (PDOException $e) {
            error_log("getScoreById Error: " . $e->getMessage());
            return 0;
        }
    }
}

// Keep all your existing calculation functions
if (!function_exists('calculateTheoryTotal')) {
    function calculateTheoryTotal($marks) {
        // Calculate best 2 out of 3 CTs (each worth 20 marks)
        $ct1 = floatval($marks['ct1'] ?? 0);
        $ct2 = floatval($marks['ct2'] ?? 0);
        $ct3 = floatval($marks['ct3'] ?? 0);
        
        $cts = [$ct1, $ct2, $ct3];
        rsort($cts); // Sort descending
        $bestTwoCT = $cts[0] + $cts[1];
        
        $assignment = floatval($marks['assignment'] ?? 0);
        $mid_term = floatval($marks['mid_term'] ?? 0);
        $attendance = floatval($marks['attendance'] ?? 0);
        $final_exam = floatval($marks['final_exam'] ?? 0);
        
        $total = $bestTwoCT + $assignment + $mid_term + $attendance + $final_exam;
        
        error_log("Theory Total Calculation: CTs=$bestTwoCT, Assignment=$assignment, Mid=$mid_term, Attendance=$attendance, Final=$final_exam, Total=$total");
        
        return $total;
    }
}

if (!function_exists('calculateSessionalTotal')) {
    function calculateSessionalTotal($marks) {
        $lab_attendance = floatval($marks['lab_attendance'] ?? 0);
        $lab_report = floatval($marks['lab_report'] ?? 0);
        $lab_mid = floatval($marks['lab_mid'] ?? 0);
        $lab_final = floatval($marks['lab_final'] ?? 0);
        $lab_viva = floatval($marks['lab_viva'] ?? 0);
        $lab_quiz = floatval($marks['lab_quiz'] ?? 0);
        
        $total = $lab_attendance + $lab_report + $lab_mid + $lab_final + $lab_viva + $lab_quiz;
        
        error_log("Sessional Total Calculation: Attendance=$lab_attendance, Report=$lab_report, Mid=$lab_mid, Final=$lab_final, Viva=$lab_viva, Quiz=$lab_quiz, Total=$total");
        
        return $total;
    }
}

if (!function_exists('validateMarks')) {
    function validateMarks($marks, $course_type) {
        // Allow empty marks (they will be treated as 0)
        if (!is_array($marks) || empty($marks)) {
            return true;
        }
        
        $max_limits = [
            'theory' => [
                'ct1' => 20,
                'ct2' => 20,
                'ct3' => 20,
                'assignment' => 15, 
                'mid_term' => 45,
                'attendance' => 20, 
                'final_exam' => 180
            ],
            'sessional' => [
                'lab_attendance' => 10, 
                'lab_report' => 20,
                'lab_mid' => 20, 
                'lab_final' => 30,
                'lab_viva' => 10, 
                'lab_quiz' => 10
            ]
        ];
        
        $limits = $max_limits[$course_type] ?? [];
        
        foreach ($marks as $component => $value) {
            // Skip empty values
            if ($value === '' || $value === null) {
                continue;
            }
            
            if (!isset($limits[$component])) {
                continue; // Skip if component not in limits (for flexibility)
            }
            
            $value = floatval($value);
            if ($value < 0 || $value > $limits[$component]) {
                error_log("Invalid mark: $component = $value, max = " . $limits[$component]);
                return false;
            }
        }
        return true;
    }
}

if (!function_exists('calculateGrade')) {
    function calculateGrade($percentage) {
        $percentage = floatval($percentage);
        
        if ($percentage >= 80) return 'A+';
        if ($percentage >= 75) return 'A';
        if ($percentage >= 70) return 'A-';
        if ($percentage >= 65) return 'B+';
        if ($percentage >= 60) return 'B';
        if ($percentage >= 55) return 'B-';
        if ($percentage >= 50) return 'C+';
        if ($percentage >= 45) return 'C';
        if ($percentage >= 40) return 'D';
        return 'F';
    }
}

if (!function_exists('getGradePoint')) {
    function getGradePoint($letter_grade) {
        $grade_points = [
            'A+' => 4.00,
            'A'  => 3.75,
            'A-' => 3.50,
            'B+' => 3.25,
            'B'  => 3.00,
            'B-' => 2.75,
            'C+' => 2.50,
            'C'  => 2.25,
            'D'  => 2.00,
            'F'  => 0.00
        ];
        
        return $grade_points[$letter_grade] ?? 0.00;
    }
}

if (!function_exists('checkTableExists')) {
    function checkTableExists($table_name, $conn) {
        try {
            $sql = "SHOW TABLES LIKE ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$table_name]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("checkTableExists Error: " . $e->getMessage());
            return false;
        }
    }
}
?>