<?php
// Teacher/req/save_score.php
session_start();

if (!isset($_SESSION['teacher_id']) || $_SESSION['role'] != 'Teacher') {
    header("Location: ../login.php");
    exit;
}

include_once "../DB_connection.php";
include_once "../data/grades_score.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $student_id = $_POST['student_id'] ?? '';
    $subject_id = $_POST['subject_id'] ?? '';
    $current_semester = $_POST['current_semester'] ?? '';
    $current_year = $_POST['current_year'] ?? '';
    $course_type = $_POST['course_type'] ?? '';
    $marks = $_POST['marks'] ?? [];
    
    $teacher_id = $_SESSION['teacher_id'];
    
    // Debug: Check what data we're receiving
    error_log("Save Score Data: student_id=$student_id, subject_id=$subject_id, course_type=$course_type");
    
    // Validate required fields
    if (empty($student_id) || empty($subject_id) || empty($course_type)) {
        header("Location: ../student-grade.php?student_id=" . urlencode($student_id) . "&error=Missing required fields");
        exit;
    }
    
    // Validate marks
    if (!validateMarks($marks, $course_type)) {
        header("Location: ../student-grade.php?student_id=" . urlencode($student_id) . "&error=Invalid marks entered. Please check the values.");
        exit;
    }
    
    try {
        // Calculate total marks and percentage based on course type
        if ($course_type == 'theory') {
            $total_marks = calculateTheoryTotal($marks);
            $percentage = ($total_marks / 300) * 100;
        } else {
            $total_marks = calculateSessionalTotal($marks);
            $percentage = ($total_marks / 100) * 100;
        }
        
        $letter_grade = calculateGrade($percentage);
        
        // Debug: Log calculation results
        error_log("Calculated: total_marks=$total_marks, percentage=$percentage, grade=$letter_grade");
        
        // Save to database
        $success = saveStudentMarks(
            $student_id, 
            $subject_id, 
            $teacher_id, 
            $current_semester, 
            $current_year, 
            $marks, 
            $total_marks, 
            $percentage, 
            $letter_grade, 
            $conn
        );
        
        if ($success) {
            header("Location: ../student-grade.php?student_id=" . urlencode($student_id) . "&success=Marks saved successfully&ssubject_id=" . urlencode($subject_id));
        } else {
            header("Location: ../student-grade.php?student_id=" . urlencode($student_id) . "&error=Failed to save marks to database&ssubject_id=" . urlencode($subject_id));
        }
        exit;
        
    } catch (Exception $e) {
        error_log("Save Score Error: " . $e->getMessage());
        header("Location: ../student-grade.php?student_id=" . urlencode($student_id) . "&error=System error: " . urlencode($e->getMessage()) . "&ssubject_id=" . urlencode($subject_id));
        exit;
    }
} else {
    header("Location: ../student-grade.php");
    exit;
}
?>