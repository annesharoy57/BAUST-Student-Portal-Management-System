<?php 
session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
       include "../DB_connection.php";
       include "data/class.php";
       include "data/grade.php";
       include "data/section.php"; 
       include "data/teacher.php";
       
       $teacher_id = $_SESSION['teacher_id'];
       $teacher = getTeacherById($teacher_id, $conn);
       $classes = getAllClasses($conn);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers - Classes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
        
        // Get teacher's classes properly with comma separation
        $teacher_class_ids = [];
        if (!empty($teacher['class'])) {
            $teacher_class_ids = explode(",", trim($teacher['class']));
            $teacher_class_ids = array_filter($teacher_class_ids);
        }
        
        if ($classes != 0 && !empty($teacher_class_ids)) {
     ?>
     <div class="container mt-5">
         <h3>My Classes</h3>

           <div class="table-responsive">
              <table class="table table-bordered mt-3 n-table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Class</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $i = 0; 
                  foreach ($classes as $class) {
                      // Check if this class belongs to the teacher
                      if (in_array($class['class_id'], $teacher_class_ids)) {
                          $i++;
                          $grade = getGradeById($class['grade'], $conn);
                          // SAFE FUNCTION CALL: Check if function exists
                          $section = function_exists('getSectionById') ? getSectionById($class['section'], $conn) : 0;
                  ?>
                  <tr>
                    <th scope="row"><?=$i?></th>
                    <td>
                        <?php 
                        if ($grade != 0 && $section != 0) {
                            echo $grade['level'] . '-' . $grade['term'] . ' ' . $section['section'];
                        } else if ($grade != 0) {
                            echo $grade['level'] . '-' . $grade['term'] . ' (No section)';
                        } else {
                            echo 'Class ' . $class['class_id'];
                        }
                        ?>
                    </td>
                  </tr>
                  <?php 
                      }
                  } 
                  ?>
                </tbody>
              </table>
           </div>
         <?php } else { ?>
             <div class="alert alert-info .w-450 m-5" role="alert">
                No classes assigned to you!
             </div>
         <?php } ?>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(2) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    } 
} else {
    header("Location: ../login.php");
    exit;
} 
?>