<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Only allow logged-in teachers
if (!isset($_SESSION['teacher_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'Teacher') {
    header("Location: ../login.php");
    exit;
}

include_once "../DB_connection.php";
include_once "data/student.php";
include_once "data/grade.php";
include_once "data/section.php";
include_once "data/setting.php";
include_once "data/subject.php";
include_once "data/teacher.php";
include_once "data/grades_score.php";

// Check if student_id is provided
if (!isset($_GET['student_id'])) {
    header("Location: students.php");
    exit;
}

$student_id = $_GET['student_id'];
$student = getStudentById($student_id, $conn);
if (!$student) {
    header("Location: students.php");
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher = getTeacherById($teacher_id, $conn);
$setting = getSetting($conn);

// Teacher's assigned subjects
$teacher_subjects = [];
if (!empty($teacher['subjects'])) {
    $teacher_subjects = array_filter(array_map('trim', explode(',', $teacher['subjects'])));
}

// Subjects for student's grade
$subjects = getSubjectByGrade($student['grade'], $conn);

// Find common subjects (student's subjects that teacher teaches)
$common_subjects = [];
if ($subjects && !empty($teacher_subjects)) {
    foreach ($subjects as $subject) {
        if (in_array((string)$subject['subject_id'], $teacher_subjects) ||
            in_array($subject['subject_id'], $teacher_subjects)) {
            $common_subjects[] = $subject;
        }
    }
}

// Initialize variables
$ssubject_id = 0;
$student_score = 0;

// Check if subject ID is coming from POST (form submission) or GET (URL parameter)
if (isset($_POST['ssubject_id'])) {
    $ssubject_id = $_POST['ssubject_id'];
} elseif (isset($_GET['ssubject_id'])) {
    $ssubject_id = $_GET['ssubject_id'];
}

if ($ssubject_id != 0) {
    $student_score = getScoreById($student_id, $teacher_id, $ssubject_id, 
                                  $setting['current_semester'], $setting['current_year'], $conn);
}

// ========== FORM SUBMISSION HANDLING ==========
// Handle form submission for saving marks
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['student_id']) && isset($_POST['subject_id'])) {
    // Get form data
    $student_id = $_POST['student_id'] ?? '';
    $subject_id = $_POST['subject_id'] ?? '';
    $current_semester = $_POST['current_semester'] ?? '';
    $current_year = $_POST['current_year'] ?? '';
    $course_type = $_POST['course_type'] ?? '';
    $marks = $_POST['marks'] ?? [];
    
    $teacher_id = $_SESSION['teacher_id'];
    
    // Get student and subject info for success message
    $student = getStudentById($student_id, $conn);
    $selected_subject = null;
    foreach($common_subjects as $subject) {
        if($subject['subject_id'] == $subject_id) {
            $selected_subject = $subject;
            break;
        }
    }
    
    // Validate required fields
    if (empty($student_id) || empty($subject_id) || empty($course_type)) {
        $_SESSION['error'] = "Missing required fields";
    } 
    // Validate marks
    else if (!validateMarks($marks, $course_type)) {
        $_SESSION['error'] = "Invalid marks entered. Please check the values.";
    } else {
        try {
            // Calculate total marks and percentage based on course type
            if ($course_type == 'theory') {
                $total_marks = calculateTheoryTotal($marks);
                $percentage = ($total_marks / 300) * 100;
            } else {
                // For sessional courses in your table structure, we'll store in available columns
                // We'll use: ct1=lab_attendance, ct2=lab_report, ct3=lab_mid, assignment=lab_final, mid_term=lab_viva, attendance=lab_quiz
                $total_marks = calculateSessionalTotal($marks);
                $percentage = ($total_marks / 100) * 100;
                
                // Map sessional marks to available theory columns for storage
                $marks_for_storage = [
                    'ct1' => $marks['lab_attendance'] ?? 0,
                    'ct2' => $marks['lab_report'] ?? 0,
                    'ct3' => $marks['lab_mid'] ?? 0,
                    'assignment' => $marks['lab_final'] ?? 0,
                    'mid_term' => $marks['lab_viva'] ?? 0,
                    'attendance' => $marks['lab_quiz'] ?? 0,
                    'final_exam' => 0 // Not used for sessional
                ];
            }
            
            $letter_grade = calculateGrade($percentage);
            
            // Save to database using the new function
            $success = saveStudentGrades(
                $student_id, 
                $subject_id, 
                $teacher_id, 
                $current_semester, 
                $current_year, 
                $course_type,
                isset($marks_for_storage) ? $marks_for_storage : $marks, 
                $total_marks, 
                $percentage, 
                $letter_grade, 
                $conn
            );
            
            if ($success) {
                $_SESSION['success'] = "✅ Marks saved successfully!<br>
                                       <strong>Student:</strong> " . htmlspecialchars($student['fname'] . ' ' . $student['lname']) . "<br>
                                       <strong>Subject:</strong> " . htmlspecialchars($selected_subject['subject_code']) . " - " . htmlspecialchars($selected_subject['subject']) . "<br>
                                       <strong>Total Marks:</strong> " . number_format($total_marks, 2) . "<br>
                                       <strong>Grade:</strong> " . $letter_grade . "<br>
                                       <small class='text-muted'>The student can now view these results in their portal.</small>";
                // Redirect to avoid form resubmission
                header("Location: student-grade.php?student_id=" . urlencode($student_id) . "&ssubject_id=" . urlencode($subject_id));
                exit;
            } else {
                $_SESSION['error'] = "Failed to save marks to database. Please try again.";
            }
            
        } catch (Exception $e) {
            $_SESSION['error'] = "System error: " . $e->getMessage();
        }
    }
    
    // If there was an error, set the subject ID to keep the form populated
    if (isset($subject_id)) {
        $ssubject_id = $subject_id;
    }
}
// ========== END FORM SUBMISSION HANDLING ==========
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher - Student Grade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../logo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .grade-table th {background-color: #343a40;color: white;text-align:center;}
        .grade-table td {vertical-align: middle;}
        .results-cell {min-width: 200px;}
        .score-input {width: 80px;text-align:center;}
        .total-score {font-weight: bold;font-size: 1.1em;}
        .component-label {font-size: 0.8em;color: #666;margin-bottom: 2px;}
        .marks-row {margin-bottom: 8px;padding: 4px;border-bottom: 1px solid #eee;}
        .badge {font-size: 0.9em;}
    </style>
</head>
<body>
    <?php include "inc/navbar.php"; ?>

    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="text-center mb-0">Student Grade Management</h4>
            </div>
            <div class="card-body">

                <!-- Alert Messages -->
                <?php if (isset($_SESSION['error'])) { ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle"></i> <?= $_SESSION['error'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php } ?>

                <?php if (isset($_SESSION['success'])) { ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> <?= $_SESSION['success'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php } ?>

                <?php if (isset($_GET['error'])) { ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($_GET['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php } ?>

                <?php if (isset($_GET['success'])) { ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php } ?>

                <!-- Student Information -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>Student Information</h5>
                        <p><strong>ID:</strong> <?= htmlspecialchars($student['student_id']) ?></p>
                        <p><strong>Name:</strong> <?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></p>
                        <?php 
                        $grade = getGradeById($student['grade'], $conn);
                        $section = getSectionById($student['section'], $conn);
                        ?>
                        <p><strong>Grade:</strong> <?= ($grade != 0) ? htmlspecialchars($grade['level'] . '-' . $grade['term']) : 'N/A' ?></p>
                        <p><strong>Section:</strong> 
                            <?php 
                            if ($section != 0) {
                                echo 'Section ' . htmlspecialchars($section['section'] ?? 'N/A');
                            } else {
                                echo 'Section ID: ' . htmlspecialchars($student['section']);
                            }
                            ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <h5>Academic Information</h5>
                        <p><strong>Year:</strong> <?= htmlspecialchars($setting['current_year']) ?></p>
                        <p><strong>Semester:</strong> <?= htmlspecialchars($setting['current_semester']) ?></p>
                        <p><strong>Institute:</strong> <?= htmlspecialchars($setting['university_name'] ?? 'N/A') ?></p>
                    </div>
                </div>

                <!-- Subject Selection -->
                <form method="post" class="mb-4">
                    <div class="mb-3">
                        <label class="form-label"><strong>Select Common Course (Student's Course that You Teach):</strong></label>
                        <select class="form-control" name="ssubject_id" required>
                            <option value="">-- Select Common Course --</option>
                            <?php 
                            if (!empty($common_subjects)) {
                                foreach($common_subjects as $subject){ 
                            ?>
                            <option value="<?= $subject['subject_id'] ?>" <?= ($ssubject_id == $subject['subject_id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($subject['subject_code']) ?> - <?= htmlspecialchars($subject['subject']) ?> (<?= ucfirst($subject['course_type']) ?>)
                            </option>
                            <?php 
                                }
                            } else {
                                echo '<option value="">No common courses found</option>';
                            }
                            ?>
                        </select>
                        
                        <?php if (empty($common_subjects)) { ?>
                        <div class="alert alert-warning mt-2">
                            <strong>No Common Courses Found!</strong><br>
                            This student is not enrolled in any courses that you teach.
                        </div>
                        <?php } ?>
                    </div>
                    
                    <?php if (!empty($common_subjects)) { ?>
                    <button type="submit" class="btn btn-primary">Load Grade Entry Form</button>
                    <?php } ?>
                </form>

                <!-- Detailed Marks Entry Form -->
                <?php if ($ssubject_id != 0 && !empty($common_subjects)) { 
                    $selected_subject = null;
                    foreach($common_subjects as $subject) {
                        if($subject['subject_id'] == $ssubject_id) {
                            $selected_subject = $subject;
                            break;
                        }
                    }
                    
                    if ($selected_subject) {
                        $existing_marks = getDetailedMarks($student_id, $ssubject_id, $setting['current_semester'], $setting['current_year'], $conn);
                ?>
                
                <form method="post" action="">
                    <h5>Detailed Marks Entry: <?= htmlspecialchars($selected_subject['subject_code']) ?> - <?= htmlspecialchars($selected_subject['subject']) ?></h5>
                    <p class="text-muted">
                        Course Type: <strong><?= ucfirst($selected_subject['course_type']) ?></strong> | 
                        Credit Hours: <strong><?= htmlspecialchars($selected_subject['credit_hours'] ?? '3.00') ?></strong>
                    </p>
                    
                    <div class="card">
                        <div class="card-body">
                            <?php if ($selected_subject['course_type'] == 'theory') { ?>
                                <!-- Theory Course Marks -->
                                <h6>Theory Course Components (Total: 300 marks)</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Class Tests (Best 2 out of 3)</div>
                                            <div class="row g-2">
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct1]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="20" step="1" placeholder="CT1" 
                                                           value="<?= isset($existing_marks['ct1']) ? htmlspecialchars($existing_marks['ct1']) : '' ?>">
                                                    <small class="text-muted">CT 1 (20)</small>
                                                </div>
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct2]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="20" step="1" placeholder="CT2"
                                                           value="<?= isset($existing_marks['ct2']) ? htmlspecialchars($existing_marks['ct2']) : '' ?>">
                                                    <small class="text-muted">CT 2 (20)</small>
                                                </div>
                                                <div class="col-4">
                                                    <input type="number" name="marks[ct3]" class="form-control form-control-sm score-input ct-marks" 
                                                           min="0" max="20" step="1" placeholder="CT3"
                                                           value="<?= isset($existing_marks['ct3']) ? htmlspecialchars($existing_marks['ct3']) : '' ?>">
                                                    <small class="text-muted">CT 3 (20)</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Assignment</div>
                                            <input type="number" name="marks[assignment]" class="form-control form-control-sm score-input" 
                                                   min="0" max="15" step="1" placeholder="0-15"
                                                   value="<?= isset($existing_marks['assignment']) ? htmlspecialchars($existing_marks['assignment']) : '' ?>">
                                            <small class="text-muted">Max: 15 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Mid Term</div>
                                            <input type="number" name="marks[mid_term]" class="form-control form-control-sm score-input" 
                                                   min="0" max="45" step="1" placeholder="0-45"
                                                   value="<?= isset($existing_marks['mid_term']) ? htmlspecialchars($existing_marks['mid_term']) : '' ?>">
                                            <small class="text-muted">Max: 45 marks</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Attendance</div>
                                            <input type="number" name="marks[attendance]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['attendance']) ? htmlspecialchars($existing_marks['attendance']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Final Exam</div>
                                            <input type="number" name="marks[final_exam]" class="form-control form-control-sm score-input" 
                                                   min="0" max="180" step="1" placeholder="0-180"
                                                   value="<?= isset($existing_marks['final_exam']) ? htmlspecialchars($existing_marks['final_exam']) : '' ?>">
                                            <small class="text-muted">Max: 180 marks</small>
                                        </div>
                                        
                                        <!-- Results Display -->
                                        <div class="marks-row bg-light p-3 rounded">
                                            <div class="row text-center">
                                                <div class="col-4">
                                                    <strong>Total</strong><br>
                                                    <span id="theoryTotalDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['total_marks']) ? number_format($existing_marks['total_marks'], 2) : '0.00' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Percentage</strong><br>
                                                    <span id="theoryPercentageDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['percentage']) ? number_format($existing_marks['percentage'], 2) . '%' : '0.00%' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Grade</strong><br>
                                                    <span id="theoryGradeDisplay" class="fw-bold fs-5 badge 
                                                        <?php 
                                                        if(isset($existing_marks['letter_grade'])) {
                                                            if($existing_marks['letter_grade'] == 'F') echo 'bg-danger';
                                                            elseif(in_array($existing_marks['letter_grade'], ['A+', 'A', 'A-'])) echo 'bg-success';
                                                            else echo 'bg-warning';
                                                        } else { 
                                                            echo 'bg-secondary'; 
                                                        } 
                                                        ?>">
                                                        <?= isset($existing_marks['letter_grade']) ? htmlspecialchars($existing_marks['letter_grade']) : 'N/A' ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <?php } else { ?>
                                <!-- Sessional Course Marks -->
                                <h6>Sessional Course Components (Total: 100 marks)</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Lab Attendance</div>
                                            <input type="number" name="marks[lab_attendance]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_attendance']) ? htmlspecialchars($existing_marks['lab_attendance']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Report</div>
                                            <input type="number" name="marks[lab_report]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['lab_report']) ? htmlspecialchars($existing_marks['lab_report']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Mid</div>
                                            <input type="number" name="marks[lab_mid]" class="form-control form-control-sm score-input" 
                                                   min="0" max="20" step="1" placeholder="0-20"
                                                   value="<?= isset($existing_marks['lab_mid']) ? htmlspecialchars($existing_marks['lab_mid']) : '' ?>">
                                            <small class="text-muted">Max: 20 marks</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="marks-row">
                                            <div class="component-label">Lab Final</div>
                                            <input type="number" name="marks[lab_final]" class="form-control form-control-sm score-input" 
                                                   min="0" max="30" step="1" placeholder="0-30"
                                                   value="<?= isset($existing_marks['lab_final']) ? htmlspecialchars($existing_marks['lab_final']) : '' ?>">
                                            <small class="text-muted">Max: 30 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Viva</div>
                                            <input type="number" name="marks[lab_viva]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_viva']) ? htmlspecialchars($existing_marks['lab_viva']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <div class="marks-row">
                                            <div class="component-label">Lab Quiz</div>
                                            <input type="number" name="marks[lab_quiz]" class="form-control form-control-sm score-input" 
                                                   min="0" max="10" step="1" placeholder="0-10"
                                                   value="<?= isset($existing_marks['lab_quiz']) ? htmlspecialchars($existing_marks['lab_quiz']) : '' ?>">
                                            <small class="text-muted">Max: 10 marks</small>
                                        </div>
                                        
                                        <!-- Results Display -->
                                        <div class="marks-row bg-light p-3 rounded">
                                            <div class="row text-center">
                                                <div class="col-4">
                                                    <strong>Total</strong><br>
                                                    <span id="sessionalTotalDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['total_marks']) ? number_format($existing_marks['total_marks'], 2) : '0.00' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Percentage</strong><br>
                                                    <span id="sessionalPercentageDisplay" class="fw-bold fs-5">
                                                        <?= isset($existing_marks['percentage']) ? number_format($existing_marks['percentage'], 2) . '%' : '0.00%' ?>
                                                    </span>
                                                </div>
                                                <div class="col-4">
                                                    <strong>Grade</strong><br>
                                                    <span id="sessionalGradeDisplay" class="fw-bold fs-5 badge 
                                                        <?php 
                                                        if(isset($existing_marks['letter_grade'])) {
                                                            if($existing_marks['letter_grade'] == 'F') echo 'bg-danger';
                                                            elseif(in_array($existing_marks['letter_grade'], ['A+', 'A', 'A-'])) echo 'bg-success';
                                                            else echo 'bg-warning';
                                                        } else { 
                                                            echo 'bg-secondary'; 
                                                        } 
                                                        ?>">
                                                        <?= isset($existing_marks['letter_grade']) ? htmlspecialchars($existing_marks['letter_grade']) : 'N/A' ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <!-- Hidden fields -->
                    <input type="hidden" name="student_id" value="<?= htmlspecialchars($student_id) ?>">
                    <input type="hidden" name="subject_id" value="<?= htmlspecialchars($ssubject_id) ?>">
                    <input type="hidden" name="current_semester" value="<?= htmlspecialchars($setting['current_semester']) ?>">
                    <input type="hidden" name="current_year" value="<?= htmlspecialchars($setting['current_year']) ?>">
                    <input type="hidden" name="course_type" value="<?= htmlspecialchars($selected_subject['course_type']) ?>">
                
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Save Detailed Marks
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="calculateTotals()">
                            <i class="fas fa-calculator"></i> Calculate
                        </button>
                        <button type="button" class="btn btn-warning" onclick="clearMarks()">
                            <i class="fas fa-trash"></i> Clear
                        </button>
                        <a href="student-grade.php?student_id=<?= htmlspecialchars($student_id) ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-refresh"></i> Refresh
                        </a>
                    </div>
                </form>  
                <?php 
                    } else {
                        echo '<div class="alert alert-warning">Selected course not found in common courses.</div>';
                    }
                } ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(4) a").addClass('active');
            calculateTotals(); // Initial calculation
            
            // Auto-calculate when inputs change
            $('.score-input').on('input', function() {
                calculateTotals();
            });
        });

        function calculateBestTwoCT() {
            let ct1 = parseFloat($('input[name="marks[ct1]"]').val()) || 0;
            let ct2 = parseFloat($('input[name="marks[ct2]"]').val()) || 0;
            let ct3 = parseFloat($('input[name="marks[ct3]"]').val()) || 0;
            
            let cts = [ct1, ct2, ct3].filter(val => val > 0);
            if (cts.length < 2) return cts.reduce((a, b) => a + b, 0);
            
            cts.sort((a, b) => b - a);
            return cts[0] + cts[1];
        }

        function calculateTheoryTotal() {
            let bestTwoCT = calculateBestTwoCT();
            let assignment = parseFloat($('input[name="marks[assignment]"]').val()) || 0;
            let midTerm = parseFloat($('input[name="marks[mid_term]"]').val()) || 0;
            let attendance = parseFloat($('input[name="marks[attendance]"]').val()) || 0;
            let finalExam = parseFloat($('input[name="marks[final_exam]"]').val()) || 0;
            
            let total = bestTwoCT + assignment + midTerm + attendance + finalExam;
            let percentage = (total / 300) * 100;
            let grade = calculateGrade(percentage);
            
            $('#theoryTotalDisplay').text(total.toFixed(2));
            $('#theoryPercentageDisplay').text(percentage.toFixed(2) + '%');
            $('#theoryGradeDisplay').text(grade).removeClass('bg-secondary bg-success bg-warning bg-danger')
                .addClass(getGradeBadgeClass(grade));
        }

        function calculateSessionalTotal() {
            let labAttendance = parseFloat($('input[name="marks[lab_attendance]"]').val()) || 0;
            let labReport = parseFloat($('input[name="marks[lab_report]"]').val()) || 0;
            let labMid = parseFloat($('input[name="marks[lab_mid]"]').val()) || 0;
            let labFinal = parseFloat($('input[name="marks[lab_final]"]').val()) || 0;
            let labViva = parseFloat($('input[name="marks[lab_viva]"]').val()) || 0;
            let labQuiz = parseFloat($('input[name="marks[lab_quiz]"]').val()) || 0;
            
            let total = labAttendance + labReport + labMid + labFinal + labViva + labQuiz;
            let percentage = (total / 100) * 100;
            let grade = calculateGrade(percentage);
            
            $('#sessionalTotalDisplay').text(total.toFixed(2));
            $('#sessionalPercentageDisplay').text(percentage.toFixed(2) + '%');
            $('#sessionalGradeDisplay').text(grade).removeClass('bg-secondary bg-success bg-warning bg-danger')
                .addClass(getGradeBadgeClass(grade));
        }

        function calculateTotals() {
            <?php if ($ssubject_id != 0 && isset($selected_subject)) { ?>
                if('<?= $selected_subject['course_type'] ?>' == 'theory') {
                    calculateTheoryTotal();
                } else {
                    calculateSessionalTotal();
                }
            <?php } ?>
        }

        function calculateGrade(percentage) {
            if (percentage >= 80) return 'A+';
            if (percentage >= 75) return 'A';
            if (percentage >= 70) return 'A-';
            if (percentage >= 65) return 'B+';
            if (percentage >= 60) return 'B';
            if (percentage >= 55) return 'B-';
            if (percentage >= 50) return 'C+';
            if (percentage >= 45) return 'C';
            if (percentage >= 40) return 'D';
            return 'F';
        }

        function getGradeBadgeClass(grade) {
            if (grade === 'F') return 'bg-danger';
            if (['A+', 'A', 'A-'].includes(grade)) return 'bg-success';
            return 'bg-warning';
        }

        function clearMarks() {
            if (confirm('Are you sure you want to clear all marks?')) {
                $('input[type="number"]').val('');
                calculateTotals();
            }
        }
    </script>
</body>
</html>