<?php 
session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
       include "../DB_connection.php";
       include "data/teacher.php";
       include "data/subject.php";
       include "data/grade.php";
       include "data/section.php";
       include "data/class.php";

       $teacher_id = $_SESSION['teacher_id'];
       
       // Debug: Check session data
       echo "<!-- Debug: Teacher ID from session: " . $teacher_id . " -->";
       
       $teacher = getTeacherById($teacher_id, $conn);
       
       // Debug: Check what getTeacherById returns
       echo "<!-- Debug: getTeacherById returned: " . ($teacher ? "SUCCESS" : "FAILED/0") . " -->";
       if ($teacher) {
           echo "<!-- Debug: Teacher username: " . $teacher['username'] . " -->";
       }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher - Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";

        if ($teacher != 0) {
     ?>
     <div class="container mt-5">
         <div class="card" style="width: 22rem;">
          <img src="../img/teacher-<?=$teacher['gender']?>.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title text-center">@<?=$teacher['username']?></h5>
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">First name: <?=$teacher['fname']?></li>
            <li class="list-group-item">Last name: <?=$teacher['lname']?></li>
            <li class="list-group-item">Username: <?=$teacher['username']?></li>
            <li class="list-group-item">Employee number: <?=$teacher['employee_number']?></li>
            <li class="list-group-item">Address: <?=$teacher['address']?></li>
            <li class="list-group-item">Date of birth: <?=$teacher['date_of_birth']?></li>
            <li class="list-group-item">Phone number: <?=$teacher['phone_number']?></li>
            <li class="list-group-item">Qualification: <?=$teacher['qualification']?></li>
            <li class="list-group-item">Email address: <?=$teacher['email_address']?></li>
            <li class="list-group-item">Gender: <?=$teacher['gender']?></li>
            <li class="list-group-item">Date of joined: <?=$teacher['date_of_joined']?></li>

            <li class="list-group-item">Subject: 
                <?php 
                   $s = '';
                   if (!empty($teacher['subjects'])) {
                       $subject_ids = explode(",", trim($teacher['subjects']));
                       $subject_ids = array_filter($subject_ids);
                       $subject_names = [];
                       foreach ($subject_ids as $subject_id) {
                          if (function_exists('getSubjectById')) {
                              $subject_data = getSubjectById($subject_id, $conn);
                          } else {
                              $subject_data = 0;
                          }
                          
                          if ($subject_data != 0) {
                              $subject_names[] = $subject_data['subject_code'];
                          }
                       }
                       $s = implode(", ", $subject_names);
                   } else {
                       $s = '<span class="text-muted">No subjects assigned</span>';
                   }
                   echo $s;
                ?>
            </li>
            <li class="list-group-item">Class: 
                  <?php 
                     $c = '';
                     if (!empty($teacher['class'])) {
                         $class_ids = explode(",", trim($teacher['class']));
                         $class_ids = array_filter($class_ids);
                         $class_names = [];
                         foreach ($class_ids as $class_id) {
                             $class_data = function_exists('getClassById') ? getClassById($class_id, $conn) : 0;
                             
                             if ($class_data != 0) {
                                 $grade_data = function_exists('getGradeById') ? getGradeById($class_data['grade'], $conn) : 0;
                                 $section_data = function_exists('getSectionById') ? getSectionById($class_data['section'], $conn) : 0;
                                 
                                 if ($grade_data != 0 && $section_data != 0) {
                                     $class_names[] = $grade_data['level'] . '-' . $grade_data['term'] . ' ' . $section_data['section'];
                                 } else if ($grade_data != 0) {
                                     $class_names[] = $grade_data['level'] . '-' . $grade_data['term'];
                                 } else {
                                     $class_names[] = 'Class ID: ' . $class_id;
                                 }
                             }
                         }
                         $c = implode(", ", $class_names);
                     } else {
                         $c = '<span class="text-muted">No classes assigned</span>';
                     }
                     echo $c;
                  ?>
            </li>
          </ul>
        </div>
     </div>
     <?php 
        } else {
            echo "<div class='container mt-5'><div class='alert alert-danger'>Teacher data not found. Please contact administrator.</div></div>";
        }
     ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(1) a").addClass('active');
        });
    </script>
</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    } 
} else {
    header("Location: ../login.php");
    exit;
} 