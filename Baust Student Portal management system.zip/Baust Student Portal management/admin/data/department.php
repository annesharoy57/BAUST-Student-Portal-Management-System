<?php
function getAllDepartments($conn) {
    $sql = "SELECT * FROM departments ORDER BY department_name";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetchAll();
    } else {
        return 0;
    }
}

function getDepartmentById($department_id, $conn) {
    $sql = "SELECT * FROM departments WHERE department_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$department_id]);
    
    if ($stmt->rowCount() == 1) {
        return $stmt->fetch();
    } else {
        return 0;
    }
}

function getDepartmentByCode($department_code, $conn) {
    $sql = "SELECT * FROM departments WHERE department_code = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$department_code]);
    
    if ($stmt->rowCount() == 1) {
        return $stmt->fetch();
    } else {
        return 0;
    }
}
?>
