<?php
// Get Student by ID
function getStudentById($student_id, $conn){
   $sql = "SELECT s.*, d.department_code, d.department_name, sec.section as section_letter
           FROM students s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           LEFT JOIN section sec ON s.section = sec.section_id 
           WHERE student_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$student_id]);

   if ($stmt->rowCount() == 1) {
     $student = $stmt->fetch();
     return $student;
   } else {
    return 0;
   }
}

// All Students 
function getAllStudents($conn){
   $sql = "SELECT s.*, d.department_code, d.department_name, g.level, g.term, sec.section as section_letter
           FROM students s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           LEFT JOIN grades g ON s.grade = g.grade_id 
           LEFT JOIN section sec ON s.section = sec.section_id 
           ORDER BY s.student_id ASC";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $students = $stmt->fetchAll();
     return $students;
   } else {
    return 0;
   }
}

// Get Students by Department
function getStudentsByDepartment($department_id, $conn) {
   $sql = "SELECT s.*, d.department_code, d.department_name, g.level, g.term, sec.section as section_letter
           FROM students s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           LEFT JOIN grades g ON s.grade = g.grade_id 
           LEFT JOIN section sec ON s.section = sec.section_id 
           WHERE s.department_id = ? 
           ORDER BY s.student_id ASC";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$department_id]);
   
   if ($stmt->rowCount() > 0) {
       return $stmt->fetchAll();
   } else {
       return 0;
   }
}

// Check if the username Unique
function unameIsUnique($uname, $conn, $student_id=0){
   $sql = "SELECT username, student_id FROM students WHERE username=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$uname]);
   
   if ($student_id == 0) {
     return $stmt->rowCount() == 0;
   } else {
     if ($stmt->rowCount() >= 1) {
       $student = $stmt->fetch();
       return $student['student_id'] == $student_id;
     } else {
       return true;
     }
   }
}

// DELETE
function removeStudent($id, $conn){
   $sql = "DELETE FROM students WHERE student_id=?";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$id]);
}

// Search 
function searchStudents($key, $conn){
   $key = preg_replace('/(?<!\\\)([%_])/', '\\\$1', $key);
   $sql = "SELECT s.*, d.department_code, d.department_name, sec.section as section_letter
           FROM students s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           LEFT JOIN sections sec ON s.section = sec.section_id 
           WHERE student_id LIKE ? 
           OR fname LIKE ?
           OR lname LIKE ?
           OR username LIKE ?
           OR phone_number LIKE ?
           OR email_address LIKE ?
           OR address LIKE ?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$key, $key, $key, $key, $key, $key, $key]);

   if ($stmt->rowCount() >= 1) {
     return $stmt->fetchAll();
   } else {
    return 0;
   }
}

// Add Student
function addStudent($fname, $lname, $username, $password, $address, $phone_number, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $grade, $section, $parent_fname, $parent_lname, $parent_phone_number, $conn) {
   $sql = "INSERT INTO students (fname, lname, username, password, address, phone_number, email_address, gender, date_of_birth, date_of_joined, department_id, grade, section, parent_fname, parent_lname, parent_phone_number) 
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$fname, $lname, $username, $password, $address, $phone_number, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $grade, $section, $parent_fname, $parent_lname, $parent_phone_number]);
}

// Update Student
function updateStudent($student_id, $fname, $lname, $username, $address, $phone_number, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $grade, $section, $parent_fname, $parent_lname, $parent_phone_number, $conn) {
   $sql = "UPDATE students 
           SET fname=?, lname=?, username=?, address=?, phone_number=?, email_address=?, gender=?, date_of_birth=?, date_of_joined=?, department_id=?, grade=?, section=?, parent_fname=?, parent_lname=?, parent_phone_number=? 
           WHERE student_id=?";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$fname, $lname, $username, $address, $phone_number, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $grade, $section, $parent_fname, $parent_lname, $parent_phone_number, $student_id]);
}
?>