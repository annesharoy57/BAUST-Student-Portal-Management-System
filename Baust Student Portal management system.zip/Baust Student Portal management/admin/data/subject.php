<?php 

// All Subjects
function getAllSubjects($conn){
   $sql = "SELECT s.*, d.department_code, d.department_name 
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           ORDER BY s.subject_code";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   }else {
    return 0;
   }
}

// Get All Subjects Sorted by Grade (1-I, 1-II, 2-I, 2-II, 3-I, 3-II)
function getAllSubjectsSorted($conn){
   $sql = "SELECT s.*, d.department_code, d.department_name, 
                  g.level, g.term,
                  CASE 
                    WHEN g.level = 1 AND g.term = 'I' THEN 1
                    WHEN g.level = 1 AND g.term = 'II' THEN 2
                    WHEN g.level = 2 AND g.term = 'I' THEN 3
                    WHEN g.level = 2 AND g.term = 'II' THEN 4
                    WHEN g.level = 3 AND g.term = 'I' THEN 5
                    WHEN g.level = 3 AND g.term = 'II' THEN 6
                    ELSE 7
                  END as sort_order
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           LEFT JOIN grades g ON s.grade = g.grade_id
           ORDER BY sort_order, s.subject_code";
   
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   } else {
    return 0;
   }
}

// Get Subjects by ID
function getSubjectById($subject_id, $conn){
   $sql = "SELECT s.*, d.department_code, d.department_name 
           FROM subjects s
           LEFT JOIN departments d ON s.department_id = d.department_id
           WHERE s.subject_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$subject_id]);

   if ($stmt->rowCount() == 1) {
     $subject = $stmt->fetch();
     return $subject;
   }else {
    return 0;
   }
}

// Get Subjects by Grade
function getSubjectsByGrade($grade_id, $conn){
   $sql = "SELECT s.*, d.department_code 
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           WHERE s.grade=? 
           ORDER BY s.subject_code";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$grade_id]);

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   }else {
    return 0;
   }
}

// Get Subjects by Department
function getSubjectsByDepartment($department_id, $conn){
   $sql = "SELECT s.*, d.department_code 
           FROM subjects s 
           JOIN departments d ON s.department_id = d.department_id 
           WHERE s.department_id=? 
           ORDER BY s.subject_code";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$department_id]);

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   }else {
    return 0;
   }
}

// Get Subjects by Teacher
function getSubjectsByTeacher($teacher_id, $conn){
   $sql = "SELECT s.*, d.department_code 
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           WHERE s.subject_id IN (
               SELECT subject_id FROM teacher_subject WHERE teacher_id=?
           )
           ORDER BY s.subject_code";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$teacher_id]);

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   }else {
    return 0;
   }
}

// Get Subjects by Course Type
function getSubjectsByCourseType($course_type, $conn){
   $sql = "SELECT s.*, d.department_code 
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           WHERE s.course_type=? 
           ORDER BY s.subject_code";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$course_type]);

   if ($stmt->rowCount() >= 1) {
     $subjects = $stmt->fetchAll();
     return $subjects;
   }else {
    return 0;
   }
}

// Add new subject
function addSubject($subject_name, $subject_code, $grade, $credit_hours, $course_type, $department_id, $max_marks, $conn){
   $sql = "INSERT INTO subjects (subject, subject_code, grade, credit_hours, course_type, department_id, max_marks) 
           VALUES (?, ?, ?, ?, ?, ?, ?)";
   $stmt = $conn->prepare($sql);
   $re   = $stmt->execute([$subject_name, $subject_code, $grade, $credit_hours, $course_type, $department_id, $max_marks]);
   if ($re) {
     return 1;
   }else {
    return 0;
   }
}

// Update subject
function updateSubject($subject_id, $subject_name, $subject_code, $grade, $credit_hours, $course_type, $department_id, $max_marks, $conn){
   $sql = "UPDATE subjects 
           SET subject=?, subject_code=?, grade=?, credit_hours=?, course_type=?, department_id=?, max_marks=?
           WHERE subject_id=?";
   $stmt = $conn->prepare($sql);
   $re   = $stmt->execute([$subject_name, $subject_code, $grade, $credit_hours, $course_type, $department_id, $max_marks, $subject_id]);
   if ($re) {
     return 1;
   }else {
    return 0;
   }
}

// DELETE subject
function removeCourse($id, $conn){
   $sql  = "DELETE FROM subjects
           WHERE subject_id=?";
   $stmt = $conn->prepare($sql);
   $re   = $stmt->execute([$id]);
   if ($re) {
     return 1;
   }else {
    return 0;
   }
}

// Check if subject code exists
function isSubjectCodeUnique($subject_code, $conn, $subject_id = null){
   if ($subject_id) {
     $sql = "SELECT * FROM subjects WHERE subject_code=? AND subject_id != ?";
     $stmt = $conn->prepare($sql);
     $stmt->execute([$subject_code, $subject_id]);
   } else {
     $sql = "SELECT * FROM subjects WHERE subject_code=?";
     $stmt = $conn->prepare($sql);
     $stmt->execute([$subject_code]);
   }

   if ($stmt->rowCount() >= 1) {
     return 0; // Not unique
   }else {
    return 1; // Unique
   }
}

// Get subject statistics
function getSubjectStatistics($conn){
   $sql = "SELECT 
           COUNT(*) as total_subjects,
           SUM(CASE WHEN course_type = 'theory' THEN 1 ELSE 0 END) as theory_subjects,
           SUM(CASE WHEN course_type = 'sessional' THEN 1 ELSE 0 END) as sessional_subjects,
           COUNT(DISTINCT department_id) as departments_with_subjects
           FROM subjects";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() == 1) {
     return $stmt->fetch();
   }else {
    return 0;
   }
}

// Get subjects with optional filters
function getSubjectsWithFilters($filters = [], $conn){
   $sql = "SELECT s.*, d.department_code, d.department_name 
           FROM subjects s 
           LEFT JOIN departments d ON s.department_id = d.department_id 
           WHERE 1=1";
   
   $params = [];
   
   if (isset($filters['department_id']) && !empty($filters['department_id'])) {
       $sql .= " AND s.department_id = ?";
       $params[] = $filters['department_id'];
   }
   
   if (isset($filters['course_type']) && !empty($filters['course_type'])) {
       $sql .= " AND s.course_type = ?";
       $params[] = $filters['course_type'];
   }
   
   if (isset($filters['grade']) && !empty($filters['grade'])) {
       $sql .= " AND s.grade = ?";
       $params[] = $filters['grade'];
   }
   
   $sql .= " ORDER BY s.subject_code";
   
   $stmt = $conn->prepare($sql);
   $stmt->execute($params);

   if ($stmt->rowCount() >= 1) {
     return $stmt->fetchAll();
   }else {
    return 0;
   }
}

?>