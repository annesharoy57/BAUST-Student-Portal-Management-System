<?php  

// Get Teacher by ID
function getTeacherById($teacher_id, $conn){
   $sql = "SELECT t.*, d.department_code, d.department_name 
           FROM teachers t 
           LEFT JOIN departments d ON t.department_id = d.department_id 
           WHERE teacher_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$teacher_id]);

   if ($stmt->rowCount() == 1) {
     $teacher = $stmt->fetch();
     return $teacher;
   } else {
    return 0; 
   }
}

// All Teachers 
function getAllTeachers($conn){
   $sql = "SELECT t.*, d.department_code, d.department_name 
           FROM teachers t 
           LEFT JOIN departments d ON t.department_id = d.department_id 
           ORDER BY t.fname";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $teachers = $stmt->fetchAll();
     return $teachers;
   } else {
    return 0; 
   }
}

// Get Teachers by Department
// Get Teachers by Department
function getTeachersByDepartment($department_id, $conn) {
   $sql = "SELECT * FROM teachers WHERE department_id = ? ORDER BY teacher_id ASC";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$department_id]);
   
   if ($stmt->rowCount() > 0) {
       return $stmt->fetchAll();
   } else {
       return 0;
   }
}

// Check if the username Unique
function unameIsUnique($uname, $conn, $teacher_id=0){
   $sql = "SELECT username, teacher_id FROM teachers WHERE username=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$uname]);
   
   if ($teacher_id == 0) {
     return $stmt->rowCount() == 0;
   } else {
     if ($stmt->rowCount() >= 1) {
       $teacher = $stmt->fetch();
       return $teacher['teacher_id'] == $teacher_id;
     } else {
       return true;
     }
   }
}

// DELETE
function removeTeacher($id, $conn){
   $sql = "DELETE FROM teachers WHERE teacher_id=?";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$id]);
}

// Search 
function searchTeachers($key, $conn){
   $key = preg_replace('/(?<!\\\)([%_])/', '\\\$1', $key);
   $sql = "SELECT t.*, d.department_code, d.department_name 
           FROM teachers t 
           LEFT JOIN departments d ON t.department_id = d.department_id 
           WHERE teacher_id LIKE ? 
           OR fname LIKE ?
           OR lname LIKE ?
           OR username LIKE ?
           OR employee_number LIKE ?
           OR phone_number LIKE ?
           OR qualification LIKE ?
           OR email_address LIKE ?
           OR address LIKE ?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$key, $key, $key, $key, $key, $key, $key, $key, $key]);

   if ($stmt->rowCount() >= 1) {
     return $stmt->fetchAll();
   } else {
    return 0;
   }
}

// Add Teacher
function addTeacher($fname, $lname, $username, $password, $address, $employee_number, $phone_number, $qualification, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $subjects, $classes, $conn) {
   $sql = "INSERT INTO teachers (fname, lname, username, password, address, employee_number, phone_number, qualification, email_address, gender, date_of_birth, date_of_joined, department_id, subjects, class) 
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$fname, $lname, $username, $password, $address, $employee_number, $phone_number, $qualification, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $subjects, $classes]);
}

// Update Teacher
function updateTeacher($teacher_id, $fname, $lname, $username, $address, $employee_number, $phone_number, $qualification, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $subjects, $classes, $conn) {
   $sql = "UPDATE teachers 
           SET fname=?, lname=?, username=?, address=?, employee_number=?, phone_number=?, qualification=?, email_address=?, gender=?, date_of_birth=?, date_of_joined=?, department_id=?, subjects=?, class=? 
           WHERE teacher_id=?";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$fname, $lname, $username, $address, $employee_number, $phone_number, $qualification, $email_address, $gender, $date_of_birth, $date_of_joined, $department_id, $subjects, $classes, $teacher_id]);
}

// Update Teacher Password
function updateTeacherPassword($teacher_id, $new_password, $conn) {
   $sql = "UPDATE teachers SET password=? WHERE teacher_id=?";
   $stmt = $conn->prepare($sql);
   return $stmt->execute([$new_password, $teacher_id]);
}

?>