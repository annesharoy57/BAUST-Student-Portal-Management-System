<?php
session_start();

// Check if admin is logged in
if (isset($_SESSION['admin_id'], $_SESSION['role']) && $_SESSION['role'] === 'Admin') {

    // Check if all required POST data exists
    if (isset($_POST['grade_id'], $_POST['level'], $_POST['term'])) {

        include "../../DB_connection.php"; // Adjust path if needed

        // Get and sanitize POST values
        $grade_id = $_POST['grade_id'];
        $level = trim($_POST['level']);
        $term = trim($_POST['term']);

        // Validate inputs
        if ($level === '' || $term === '') {
            $em = "Level and Term cannot be empty";
            header("Location: ../grade-edit.php?grade_id=$grade_id&error=" . urlencode($em));
            exit;
        }

        try {
            // Prepare and execute the update query
            $sql = "UPDATE grades SET level = ?, term = ? WHERE grade_id = ?";
            $stmt = $conn->prepare($sql);
            $updated = $stmt->execute([$level, $term, $grade_id]);

            if ($updated) {
                header("Location: ../grade.php?success=" . urlencode("Grade updated successfully"));
                exit;
            } else {
                header("Location: ../grade-edit.php?grade_id=$grade_id&error=" . urlencode("Failed to update grade"));
                exit;
            }

        } catch (PDOException $e) {
            header("Location: ../grade-edit.php?grade_id=$grade_id&error=" . urlencode("Database error: " . $e->getMessage()));
            exit;
        }

    } else {
        header("Location: ../grade.php?error=" . urlencode("Invalid request"));
        exit;
    }

} else {
    header("Location: ../../logout.php");
    exit;
}
?>
