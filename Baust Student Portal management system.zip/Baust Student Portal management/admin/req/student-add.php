<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
        
        if (isset($_POST['fname']) &&
            isset($_POST['lname']) &&
            isset($_POST['username']) &&
            isset($_POST['pass'])     &&
            isset($_POST['address'])  &&
            isset($_POST['gender'])   &&
            isset($_POST['email_address']) &&
            isset($_POST['date_of_birth']) &&
            isset($_POST['date_of_joined']) &&
            isset($_POST['parent_fname'])  &&
            isset($_POST['parent_lname'])  &&
            isset($_POST['parent_phone_number']) && // CORRECTED: parent_phone_number
            isset($_POST['phone_number']) &&
            isset($_POST['department_id']) &&
            isset($_POST['section']) &&
            isset($_POST['grade'])) {
            
            include '../../DB_connection.php';
            include "../data/student.php";
            include "../data/department.php";

            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['username'];
            $pass = $_POST['pass'];
            $address = $_POST['address'];
            $gender = $_POST['gender'];
            $email_address = $_POST['email_address'];
            $date_of_birth = $_POST['date_of_birth'];
            $date_of_joined = $_POST['date_of_joined'];
            $parent_fname = $_POST['parent_fname'];
            $parent_lname = $_POST['parent_lname'];
            $parent_phone_number = $_POST['parent_phone_number']; // CORRECTED
            $phone_number = $_POST['phone_number'];
            $department_id = $_POST['department_id'];
            $grade = $_POST['grade'];
            $section = $_POST['section'];

            $data = 'uname='.$uname.'&fname='.$fname.'&lname='.$lname.'&address='.$address.'&email='.$email_address.'&pfn='.$parent_fname.'&pln='.$parent_lname.'&ppn='.$parent_phone_number;

            if (empty($fname)) {
                $em  = "First name is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($lname)) {
                $em  = "Last name is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($uname)) {
                $em  = "Username is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (!unameIsUnique($uname, $conn)) {
                $em  = "Username is taken! try another";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($pass)) {
                $em  = "Password is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($address)) {
                $em  = "Address is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($gender)) {
                $em  = "Gender is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($email_address)) {
                $em  = "Email address is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($date_of_birth)) {
                $em  = "Date of birth is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($date_of_joined)) {
                $em  = "Date of joined is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($phone_number)) {
                $em  = "Phone number is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($department_id)) {
                $em  = "Department is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($parent_fname)) {
                $em  = "Parent first name is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($parent_lname)) {
                $em  = "Parent last name is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($parent_phone_number)) { // CORRECTED
                $em  = "Parent phone number is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($section)) {
                $em  = "Section is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else if (empty($grade)) {
                $em  = "Grade is required";
                header("Location: ../student-add.php?error=$em&$data");
                exit;
            } else {
                // hashing the password
                $pass = password_hash($pass, PASSWORD_DEFAULT);
                
                // CORRECTED SQL QUERY - removed roll_number, fixed field names
                $sql  = "INSERT INTO students
                        (username, password, fname, lname, grade, section, address, 
                         date_of_birth, parent_fname, parent_lname, parent_phone_number, 
                         gender, date_of_joined, phone_number, email_address, department_id)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    $uname, $pass, $fname, $lname, $grade, $section, 
                    $address, $date_of_birth, $parent_fname, 
                    $parent_lname, $parent_phone_number, $gender, $date_of_joined, 
                    $phone_number, $email_address, $department_id
                ]);
                $sm = "New student registered successfully";
                header("Location: ../student-add.php?success=$sm");
                exit;
            }
            
        } else {
            $em = "Required fields are missing";
            header("Location: ../student-add.php?error=$em");
            exit;
        }

    } else {
        header("Location: ../../logout.php");
        exit;
    } 
} else {
    header("Location: ../../logout.php");
    exit;
}