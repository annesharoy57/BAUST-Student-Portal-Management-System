<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
      
      // Fix the include paths - adjust based on actual file location
      if (file_exists('../../DB_connection.php')) {
          include_once '../../DB_connection.php'; // If DB_connection is in root
      } else if (file_exists('../DB_connection.php')) {
          include_once '../DB_connection.php'; // If DB_connection is in admin folder
      } else {
          die("Database connection file not found");
      }
      
      include_once '../data/subject.php';

      $course_name = $_POST['course_name'];
      $course_code = $_POST['course_code'];
      $grade = $_POST['grade'];
      $credit_hours = $_POST['credit_hours'];
      $course_type = $_POST['course_type'];
      $department_id = $_POST['department_id'];
      $max_marks = $_POST['max_marks'];

      if (empty($course_name)) {
        $em  = "Course name is required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($course_code)) {
        $em  = "Course code is required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($grade)) {
        $em  = "Grade is required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($credit_hours)) {
        $em  = "Credit hours are required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($course_type)) {
        $em  = "Course type is required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($department_id)) {
        $em  = "Department is required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else if (empty($max_marks)) {
        $em  = "Maximum marks are required";
        header("Location: ../course-add.php?error=$em");
        exit;
      } else {
        // Check if course code already exists
        if (!isSubjectCodeUnique($course_code, $conn)) {
          $em  = "Course code already exists";
          header("Location: ../course-add.php?error=$em");
          exit;
        }

        // Add the new course
        $sql = "INSERT INTO subjects (subject, subject_code, grade, credit_hours, course_type, department_id, max_marks) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$course_name, $course_code, $grade, $credit_hours, $course_type, $department_id, $max_marks]);
        
        $sm = "New course created successfully";
        header("Location: ../course-add.php?success=$sm");
        exit;
      }

    } else {
      header("Location: ../login.php");
      exit;
    } 
  } else {
    header("Location: ../login.php");
    exit;
  } 
?>