<?php 
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Admin') {
        
        if (isset($_POST['fname']) &&
            isset($_POST['lname']) &&
            isset($_POST['username']) &&
            isset($_POST['teacher_id']) &&
            isset($_POST['address']) &&
            isset($_POST['employee_number']) &&
            isset($_POST['phone_number']) &&
            isset($_POST['qualification']) &&
            isset($_POST['email_address']) &&
            isset($_POST['gender']) &&
            isset($_POST['date_of_birth']) &&
            isset($_POST['date_of_joined']) &&        // ADD THIS
            isset($_POST['department_id'])) {         // ADD THIS
            
            include '../../DB_connection.php';
            include "../data/teacher.php";
            include "../data/department.php";         // ADD THIS

            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['username'];
            $address = $_POST['address'];
            $employee_number = $_POST['employee_number'];
            $phone_number = $_POST['phone_number'];
            $qualification = $_POST['qualification'];
            $email_address = $_POST['email_address'];
            $gender = $_POST['gender'];
            $date_of_birth = $_POST['date_of_birth'];
            $date_of_joined = $_POST['date_of_joined'];      // ADD THIS
            $department_id = $_POST['department_id'];        // ADD THIS
            $teacher_id = $_POST['teacher_id'];
            
            // Store classes with comma separation
            $classes = "";
            if (isset($_POST['classes'])) {
                $classes = implode(",", $_POST['classes']);
            }

            // Store subjects with comma separation
            $subjects = "";
            if (isset($_POST['subjects'])) {
                $subjects = implode(",", $_POST['subjects']);
            }

            $data = 'teacher_id=' . $teacher_id;

            // Validation
            if (empty($fname)) {
                $em = "First name is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($lname)) {
                $em = "Last name is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($uname)) {
                $em = "Username is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (!unameIsUnique($uname, $conn, $teacher_id)) {
                $em = "Username is taken! try another";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($address)) {
                $em = "Address is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($employee_number)) {
                $em = "Employee number is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($phone_number)) {
                $em = "Phone number is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($qualification)) {
                $em = "Qualification is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($email_address)) {
                $em = "Email address is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($gender)) {
                $em = "Gender is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($date_of_birth)) {
                $em = "Date of birth is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($date_of_joined)) {      // ADD THIS VALIDATION
                $em = "Date of joined is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else if (empty($department_id)) {       // ADD THIS VALIDATION
                $em = "Department is required";
                header("Location: ../teacher-edit.php?error=$em&$data");
                exit;
            } else {
                // Update teacher with department and date_of_joined
                $sql = "UPDATE teachers 
                        SET fname=?, lname=?, username=?, address=?, employee_number=?, phone_number=?, qualification=?, email_address=?, gender=?, date_of_birth=?, date_of_joined=?, department_id=?, subjects=?, class=? 
                        WHERE teacher_id=?";
                
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    $fname, $lname, $uname, $address, $employee_number, 
                    $phone_number, $qualification, $email_address, $gender, 
                    $date_of_birth, $date_of_joined, $department_id, $subjects, 
                    $classes, $teacher_id
                ]);
                
                $sm = "Teacher updated successfully!";
                header("Location: ../teacher-edit.php?success=$sm&$data");
                exit;
            }
            
        } else {
            $em = "All fields are required";
            header("Location: ../teacher.php?error=$em");
            exit;
        }

    } else {
        header("Location: ../../logout.php");
        exit;
    } 
} else {
    header("Location: ../../logout.php");
    exit;
}
?>