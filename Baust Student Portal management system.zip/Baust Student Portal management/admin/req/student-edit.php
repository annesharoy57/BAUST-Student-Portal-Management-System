<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
        
        if (isset($_POST['fname'])      &&
            isset($_POST['lname'])      &&
            isset($_POST['username'])   &&
            isset($_POST['student_id']) &&
            isset($_POST['address'])    &&
            isset($_POST['email_address']) &&
            isset($_POST['gender'])        &&
            isset($_POST['date_of_birth']) &&
            isset($_POST['date_of_joined']) &&
            isset($_POST['department_id'])  &&
            isset($_POST['section'])       &&
            isset($_POST['parent_fname'])  &&
            isset($_POST['parent_lname'])  &&
            isset($_POST['parent_phone_number']) &&
            isset($_POST['phone_number']) &&
            isset($_POST['grade'])) {
            
            include '../../DB_connection.php';
            include "../data/student.php";

            // Get all form data
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['username'];
            $address = $_POST['address'];
            $gender = $_POST['gender'];
            $section = $_POST['section'];
            $email_address = $_POST['email_address'];
            $date_of_birth = $_POST['date_of_birth'];
            $date_of_joined = $_POST['date_of_joined'];
            $department_id = $_POST['department_id'];
            $parent_fname = $_POST['parent_fname'];
            $parent_lname = $_POST['parent_lname'];
            $parent_phone_number = $_POST['parent_phone_number'];
            $phone_number = $_POST['phone_number'];
            $student_id = $_POST['student_id'];
            $grade = $_POST['grade'];

            $data = 'student_id='.$student_id;

            // Validation
            if (empty($fname)) {
                $em  = "First name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($lname)) {
                $em  = "Last name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($uname)) {
                $em  = "Username is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (!unameIsUnique($uname, $conn, $student_id)) {
                $em  = "Username is taken! try another";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($address)) {
                $em  = "Address is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($gender)) {
                $em  = "Gender is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($email_address)) {
                $em  = "Email address is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($date_of_birth)) {
                $em  = "Date of birth is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($phone_number)) {
                $em  = "Student phone number is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($parent_fname)) {
                $em  = "Parent first name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($parent_lname)) {
                $em  = "Parent last name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($parent_phone_number)) {
                $em  = "Parent phone number is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($section)) {
                $em  = "Section is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($grade)) {
                $em  = "Grade is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else {
                // Use the updated student function with phone_number
                $result = updateStudent(
                    $student_id, $fname, $lname, $uname, $address, 
                    $phone_number, $email_address, $gender, $date_of_birth, 
                    $date_of_joined, $department_id, $grade, $section, 
                    $parent_fname, $parent_lname, $parent_phone_number, $conn
                );
                
                if ($result) {
                    $sm = "Successfully updated!";
                    header("Location: ../student-edit.php?success=$sm&$data");
                    exit;
                } else {
                    $em = "Failed to update student";
                    header("Location: ../student-edit.php?error=$em&$data");
                    exit;
                }
            }
            
        } else {
            $em = "Required fields are missing";
            header("Location: ../student-edit.php?error=$em&student_id=".$_POST['student_id']);
            exit;
        }

    } else {
        header("Location: ../../logout.php");
        exit;
    } 
} else {
    header("Location: ../../logout.php");
    exit;
}