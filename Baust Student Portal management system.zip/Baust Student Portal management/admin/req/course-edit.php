<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
      
      // Fix the include paths - adjust based on actual file location
      if (file_exists('../../DB_connection.php')) {
          include_once '../../DB_connection.php'; // If DB_connection is in root
      } else if (file_exists('../DB_connection.php')) {
          include_once '../DB_connection.php'; // If DB_connection is in admin folder
      } else {
          die("Database connection file not found");
      }
      
      include_once '../data/subject.php';

      $course_id = $_POST['course_id'];
      $course_name = $_POST['course_name'];
      $course_code = $_POST['course_code'];
      $grade = $_POST['grade'];
      $credit_hours = $_POST['credit_hours'];
      $course_type = $_POST['course_type'];
      $department_id = $_POST['department_id'];
      $max_marks = $_POST['max_marks'];

      if (empty($course_name)) {
        $em  = "Course name is required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($course_code)) {
        $em  = "Course code is required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($grade)) {
        $em  = "Grade is required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($credit_hours)) {
        $em  = "Credit hours are required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($course_type)) {
        $em  = "Course type is required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($department_id)) {
        $em  = "Department is required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else if (empty($max_marks)) {
        $em  = "Maximum marks are required";
        header("Location: ../course-edit.php?course_id=$course_id&error=$em");
        exit;
      } else {
        // Check if course code already exists (excluding current course)
        if (!isSubjectCodeUnique($course_code, $conn, $course_id)) {
          $em  = "Course code already exists";
          header("Location: ../course-edit.php?course_id=$course_id&error=$em");
          exit;
        }

        // Update the course
        $sql = "UPDATE subjects 
                SET subject=?, subject_code=?, grade=?, credit_hours=?, course_type=?, department_id=?, max_marks=?
                WHERE subject_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$course_name, $course_code, $grade, $credit_hours, $course_type, $department_id, $max_marks, $course_id]);
        
        $sm = "Course updated successfully";
        header("Location: ../course-edit.php?course_id=$course_id&success=$sm");
        exit;
      }

    } else {
      header("Location: ../login.php");
      exit;
    } 
  } else {
    header("Location: ../login.php");
    exit;
  } 
?>