<?php 
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Admin') {
        
        if (isset($_POST['fname']) &&
            isset($_POST['lname']) &&
            isset($_POST['username']) &&
            isset($_POST['address']) &&
            isset($_POST['employee_number']) &&
            isset($_POST['phone_number']) &&
            isset($_POST['qualification']) &&
            isset($_POST['email_address']) &&
            isset($_POST['gender']) &&
            isset($_POST['date_of_birth']) &&
            isset($_POST['pass']) && // CHANGED: from 'password' to 'pass'
            isset($_POST['cpass']) && // CHANGED: from 'cpassword' to 'cpass'
            isset($_POST['department_id']) &&
            isset($_POST['date_of_joined'])) {

            include '../../DB_connection.php';
            include "../data/teacher.php";
            include "../data/department.php";

            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['username'];
            $address = $_POST['address'];
            $employee_number = $_POST['employee_number'];
            $phone_number = $_POST['phone_number'];
            $qualification = $_POST['qualification'];
            $email_address = $_POST['email_address'];
            $gender = $_POST['gender'];
            $date_of_birth = $_POST['date_of_birth'];
            $pass = $_POST['pass']; // CHANGED: from 'password' to 'pass'
            $cpass = $_POST['cpass']; // CHANGED: from 'cpassword' to 'cpass'
            $department_id = $_POST['department_id'];
            $date_of_joined = $_POST['date_of_joined'];
            
            // Store classes with comma separation
            $classes = "";
            if (isset($_POST['classes'])) {
                $classes = implode(",", $_POST['classes']);
            }

            // Store subjects with comma separation
            $subjects = "";
            if (isset($_POST['subjects'])) {
                $subjects = implode(",", $_POST['subjects']);
            }

            // Validation
            if (empty($fname)) {
                $em = "First name is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($lname)) {
                $em = "Last name is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($uname)) {
                $em = "Username is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (!unameIsUnique($uname, $conn)) {
                $em = "Username is taken! try another";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($address)) {
                $em = "Address is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($employee_number)) {
                $em = "Employee number is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($phone_number)) {
                $em = "Phone number is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($qualification)) {
                $em = "Qualification is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($email_address)) {
                $em = "Email address is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($gender)) {
                $em = "Gender is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($date_of_birth)) {
                $em = "Date of birth is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($department_id)) {
                $em = "Department is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($date_of_joined)) {
                $em = "Date of joined is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($pass)) {
                $em = "Password is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if (empty($cpass)) {
                $em = "Confirmation password is required";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else if ($pass !== $cpass) {
                $em = "Password and confirm password does not match";
                header("Location: ../teacher-add.php?error=$em");
                exit;
            } else {
                // Hashing the password
                $pass = password_hash($pass, PASSWORD_DEFAULT);

                $sql = "INSERT INTO teachers (username, password, fname, lname, subjects, class, address, employee_number, date_of_birth, phone_number, qualification, gender, email_address, department_id, date_of_joined) 
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->execute([$uname, $pass, $fname, $lname, $subjects, $classes, $address, $employee_number, $date_of_birth, $phone_number, $qualification, $gender, $email_address, $department_id, $date_of_joined]);
                
                $sm = "New teacher created successfully";
                header("Location: ../teacher-add.php?success=$sm");
                exit;
            }
            
        } else {
            $em = "An error occurred - Missing required fields";
            header("Location: ../teacher-add.php?error=$em");
            exit;
        }

    } else {
        header("Location: ../../logout.php");
        exit;
    } 
} else {
    header("Location: ../../logout.php");
    exit;
}
?>