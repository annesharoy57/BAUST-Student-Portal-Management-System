<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])     &&
    isset($_GET['course_id'])) {

    if ($_SESSION['role'] == 'Admin') {
      
       include "../DB_connection.php";
       include "data/subject.php";
       include "data/grade.php";
       include "data/department.php";
       
       $course_id = $_GET['course_id'];
       $course = getSubjectById($course_id, $conn);
       $grades = getAllGrades($conn);
       $departments = getAllDepartments($conn);

       if ($course == 0) {
         header("Location: course.php");
         exit;
       }

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Edit Course</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
     ?>
     <div class="container mt-5">
        <a href="course.php"
           class="btn btn-dark">Go Back</a>

        <form method="post"
              class="shadow p-3 mt-5 form-w" 
              action="req/course-edit.php">
        <h3>Edit Course</h3><hr>
        <?php if (isset($_GET['error'])) { ?>
          <div class="alert alert-danger" role="alert">
           <?=$_GET['error']?>
          </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
          <div class="alert alert-success" role="alert">
           <?=$_GET['success']?>
          </div>
        <?php } ?>
        
        <div class="mb-3">
          <label class="form-label">Course Name</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$course['subject']?>" 
                 name="course_name"
                 required>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Course Code</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$course['subject_code']?>" 
                 name="course_code"
                 required>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Grade</label>
          <select name="grade" class="form-control" required>
            <?php foreach ($grades as $grade) { 
                $selected = ($grade['grade_id'] == $course['grade']) ? 'selected' : '';
            ?>
              <option value="<?=$grade['grade_id']?>" <?=$selected?>>
                 <?=$grade['level'].'-'.$grade['term']?>
              </option> 
            <?php } ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Credit Hours</label>
          <input type="number" 
                 class="form-control"
                 name="credit_hours"
                 step="0.5"
                 min="0.5"
                 max="6"
                 value="<?=$course['credit_hours'] ?? '3.00'?>"
                 required>
          <div class="form-text">Typically 3.00 for most courses</div>
        </div>

        <div class="mb-3">
          <label class="form-label">Course Type</label>
          <select name="course_type" class="form-control" required id="courseType">
            <option value="theory" <?=($course['course_type'] ?? 'theory') == 'theory' ? 'selected' : ''?>>Theory (300 marks)</option>
            <option value="sessional" <?=($course['course_type'] ?? 'theory') == 'sessional' ? 'selected' : ''?>>Sessional (100 marks)</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Department</label>
          <select name="department_id" class="form-control" required>
            <option value="">Select Department</option>
            <?php if ($departments != 0) {
              foreach($departments as $department) { 
                $selected = ($department['department_id'] == $course['department_id']) ? 'selected' : '';
              ?>
              <option value="<?=$department['department_id']?>" <?=$selected?>>
                 <?=$department['department_code']?> - <?=$department['department_name']?>
              </option> 
            <?php }} ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Maximum Marks</label>
          <input type="number" 
                 class="form-control"
                 name="max_marks"
                 id="maxMarks"
                 value="<?=$course['max_marks'] ?? '300'?>"
                 required>
          <div class="form-text" id="marksDescription">
            <?php 
            if (($course['course_type'] ?? 'theory') == 'sessional') {
                echo 'Sessional courses: 100 marks';
            } else {
                echo 'Theory courses: 300 marks';
            }
            ?>
          </div>
        </div>
        
        <input type="text" 
               class="form-control"
               value="<?=$course['subject_id']?>"
               name="course_id"
               hidden>

        <button type="submit" class="btn btn-primary">Update Course</button>
     </form>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>  
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(8) a").addClass('active');
            
            // Auto-update max marks based on course type
            $('#courseType').change(function(){
                var courseType = $(this).val();
                if (courseType === 'sessional') {
                    $('#maxMarks').val(100);
                    $('#marksDescription').text('Sessional courses: 100 marks');
                } else {
                    $('#maxMarks').val(300);
                    $('#marksDescription').text('Theory courses: 300 marks');
                }
            });
        });
    </script>

</body>
</html>
<?php 
  }else {
    header("Location: course.php");
    exit;
  } 
}else {
  header("Location: course.php");
  exit;
} 
?>