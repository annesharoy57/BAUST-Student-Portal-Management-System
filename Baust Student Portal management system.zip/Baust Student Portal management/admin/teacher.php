<?php
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Admin') {
        
        include "../DB_connection.php";
        include "data/teacher.php";
        include "data/department.php";
        include "data/subject.php";
        include "data/grade.php";
        include "data/class.php";
        include "data/section.php";

        // Handle department filtering
        $department_filter = "";
        if (isset($_GET['department']) && !empty($_GET['department'])) {
            $department_id = $_GET['department'];
            $teachers = getTeachersByDepartment($department_id, $conn);
            $department_filter = "&department=" . $department_id;
        } else {
            $teachers = getAllTeachers($conn);
        }

        $departments = getAllDepartments($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Teachers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php include "inc/navbar.php"; ?>
    
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Teacher List</h2>
            <a href="teacher-add.php" class="btn btn-primary">Add New Teacher</a>
        </div>

        <!-- Department Filter Form -->
        <form method="get" action="teacher.php" class="mt-3">
            <div class="row">
                <div class="col-md-8">
                    <select name="department" class="form-select">
                        <option value="">All Departments</option>
                        <?php 
                        if ($departments != 0) {
                            foreach($departments as $department) {
                                $selected = (isset($_GET['department']) && $_GET['department'] == $department['department_id']) ? 'selected' : '';
                        ?>
                        <option value="<?=$department['department_id']?>" <?=$selected?>>
                            <?=$department['department_code']?> - <?=$department['department_name']?>
                        </option>
                        <?php }} ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Filter by Department</button>
                    <?php if (isset($_GET['department'])) { ?>
                        <a href="teacher.php" class="btn btn-secondary">Clear Filter</a>
                    <?php } ?>
                </div>
            </div>
        </form>

        <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger mt-3" role="alert">
                <?=$_GET['error']?>
            </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success mt-3" role="alert">
                <?=$_GET['success']?>
            </div>
        <?php } ?>

        <div class="table-responsive mt-4">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Department</th>
                        <th scope="col">Class</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($teachers != 0) { 
                        $i = 0;
                        foreach($teachers as $teacher) {
                            $i++;
                    ?>
                    <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?=$teacher['teacher_id']?></td>
                        <td>
                            <img src="../img/teacher-<?=$teacher['gender']?>.png" 
                                 width="20" height="20" 
                                 class="me-2">
                            <!-- Make name clickable to view profile -->
                            <a href="teacher-view.php?teacher_id=<?=$teacher['teacher_id']?>" 
                               class="text-decoration-none" 
                               title="View Teacher Profile">
                                <?=$teacher['fname']?>
                            </a>
                        </td>
                        <td>
                            <a href="teacher-view.php?teacher_id=<?=$teacher['teacher_id']?>" 
                               class="text-decoration-none"
                               title="View Teacher Profile">
                                <?=$teacher['lname']?>
                            </a>
                        </td>
                        <td><?=$teacher['username']?></td>
                        <td>
                            <?php 
                            if (!empty($teacher['department_id'])) {
                                $department = getDepartmentById($teacher['department_id'], $conn);
                                if ($department != 0) {
                                    echo $department['department_code'];
                                } else {
                                    echo '<span class="text-muted">Not assigned</span>';
                                }
                            } else {
                                echo '<span class="text-muted">Not assigned</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            $c = '';
                            if (!empty($teacher['class']) && trim($teacher['class']) != '') {
                                $class_ids = explode(",", trim($teacher['class']));
                                $class_ids = array_filter($class_ids);
                                $class_names = [];
                                
                                foreach ($class_ids as $class_id) {
                                    $class_id = trim($class_id);
                                    if (!empty($class_id) && is_numeric($class_id)) {
                                        $class_data = getClassById($class_id, $conn);
                                        if ($class_data != 0) {
                                            // Get grade information
                                            $grade_data = getGradeById($class_data['grade'], $conn);
                                            $section_data = getSectionById($class_data['section'], $conn);
                                            
                                            if ($grade_data != 0 && $section_data != 0) {
                                                $class_names[] = $grade_data['level'] . '-' . $grade_data['term'] . ' ' . $section_data['section'];
                                            } else if ($grade_data != 0) {
                                                $class_names[] = $grade_data['level'] . '-' . $grade_data['term'];
                                            } else {
                                                $class_names[] = 'Class ' . $class_data['class_id'];
                                            }
                                        }
                                    }
                                }
                                
                                if (!empty($class_names)) {
                                    $c = implode(", ", $class_names);
                                } else {
                                    $c = '<span class="text-muted">No valid classes</span>';
                                }
                            } else {
                                $c = '<span class="text-muted">No classes assigned</span>';
                            }
                            echo $c;
                            ?>
                        </td>
                        <td>
                            <a href="teacher-edit.php?teacher_id=<?=$teacher['teacher_id']?>" 
                               class="btn btn-warning btn-sm">Edit</a>
                            <a href="teacher-delete.php?teacher_id=<?=$teacher['teacher_id']?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this teacher?')">Delete</a>
                        </td>
                    </tr>
                    <?php }} else { ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <div class="text-muted">
                                <?php if (isset($_GET['department'])) { ?>
                                    No teachers found in this department.
                                <?php } else { ?>
                                    No teachers found.
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(2) a").addClass('active');
        });
    </script>
</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>