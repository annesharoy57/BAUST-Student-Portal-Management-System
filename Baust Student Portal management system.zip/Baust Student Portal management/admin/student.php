<?php
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Admin') {
        
        include "../DB_connection.php";
        include "data/student.php";
        include "data/department.php";
        include "data/grade.php";
        include "data/section.php"; 

        // Handle department filtering
        $department_filter = "";
        if (isset($_GET['department']) && !empty($_GET['department'])) {
            $department_id = $_GET['department'];
            $students = getStudentsByDepartment($department_id, $conn);
            $department_filter = "&department=" . $department_id;
        } else {
            $students = getAllStudents($conn);
        }

        $departments = getAllDepartments($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
    <?php include "inc/navbar.php"; ?>
    
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Students List</h2>
            <a href="student-add.php" class="btn btn-primary">Add New Student</a>
        </div>

        <!-- Department Filter Form -->
        <form method="get" action="student.php" class="mt-3">
            <div class="row">
                <div class="col-md-8">
                    <select name="department" class="form-select">
                        <option value="">All Departments</option>
                        <?php 
                        if ($departments != 0) {
                            foreach($departments as $department) {
                                $selected = (isset($_GET['department']) && $_GET['department'] == $department['department_id']) ? 'selected' : '';
                        ?>
                        <option value="<?=$department['department_id']?>" <?=$selected?>>
                            <?=$department['department_code']?> - <?=$department['department_name']?>
                        </option>
                        <?php }} ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Filter by Department</button>
                    <?php if (isset($_GET['department'])) { ?>
                        <a href="student.php" class="btn btn-secondary">Clear Filter</a>
                    <?php } ?>
                </div>
            </div>
        </form>

        <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger mt-3" role="alert">
                <?=$_GET['error']?>
            </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success mt-3" role="alert">
                <?=$_GET['success']?>
            </div>
        <?php } ?>

        <div class="table-responsive mt-4">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Department</th>
                        <th scope="col">Grade</th>
                        <th scope="col">Section</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($students != 0) { 
                        $i = 0;
                        foreach($students as $student) {
                            $i++;
                    ?>
                    <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?=$student['student_id']?></td>
                        <td>
                            <img src="../img/student-<?=$student['gender']?>.png" width="20" height="20" class="me-2">
                            <a href="student-view.php?student_id=<?=$student['student_id']?>" 
                               class="text-decoration-none" 
                               title="View Student Profile">
                                <?=$student['fname']?>
                            </a>
                        </td>
                        <td>
                            <a href="student-view.php?student_id=<?=$student['student_id']?>" 
                               class="text-decoration-none"
                               title="View Student Profile">
                                <?=$student['lname']?>
                            </a>
                        </td>
                        <td><?=$student['username']?></td>
                        <td>
                            <?php if (!empty($student['department_code'])) { ?>
                                <?=$student['department_code']?>
                            <?php } else { ?>
                                <span class="text-muted">Not assigned</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php 
                            // Display grade as "Level-Term" (e.g., "1-I")
                            if (!empty($student['level']) && !empty($student['term'])) {
                                echo $student['level'] . '-' . $student['term'];
                            } else {
                                echo $student['grade']; // Fallback to grade ID
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            // Display section letter (A, B, C) instead of ID
                            if (!empty($student['section_letter'])) {
                                echo $student['section_letter'];
                            } else {
                                echo '<span class="text-muted">N/A</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <a href="student-edit.php?student_id=<?=$student['student_id']?>" 
                               class="btn btn-warning btn-sm">Edit</a>
                            <a href="student-delete.php?student_id=<?=$student['student_id']?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this student?')">Delete</a>
                        </td>
                    </tr>
                    <?php }} else { ?>
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <div class="text-muted">
                                <?php if (isset($_GET['department'])) { ?>
                                    No students found in this department.
                                <?php } else { ?>
                                    No students found.
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>
</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>