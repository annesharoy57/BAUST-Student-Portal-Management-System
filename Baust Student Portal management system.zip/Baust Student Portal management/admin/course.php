<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
       include "../DB_connection.php";
       include "data/subject.php";
       include "data/grade.php";
       include "data/department.php";
       
       $courses = getAllSubjectsSorted($conn);
       
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Course</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
        if ($courses != 0) {
     ?>
     <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Courses List</h2>
            <a href="course-add.php" class="btn btn-primary">Add New Course</a>
        </div>

        <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger mt-3" role="alert">
              <?=$_GET['error']?>
            </div>
        <?php } ?>

        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success mt-3" role="alert">
              <?=$_GET['success']?>
            </div>
        <?php } ?>

        <div class="table-responsive mt-4">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Course</th>
                    <th scope="col">Course Code</th>
                    <th scope="col">Grade</th>
                    <th scope="col">Credit Hours</th>
                    <th scope="col">Course Type</th>
                    <th scope="col">Department</th>
                    <th scope="col">Max Marks</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $i = 0; 
                  foreach ($courses as $course) { 
                    $i++;  
                  ?>
                  <tr>
                    <th scope="row"><?=$i?></th>
                    <td><?=$course['subject']?></td>
                    <td><?=$course['subject_code']?></td>
                    <td>
                      <?php 
                          $grade = getGradeById($course['grade'], $conn);
                          echo $grade['level'].'-'.$grade['term'];
                       ?>
                    </td>
                    <td>
                      <?php 
                          echo $course['credit_hours'] ?? '3.00';
                       ?>
                    </td>
                    <td>
                      <?php 
                          $course_type = $course['course_type'] ?? 'theory';
                          echo ucfirst($course_type);
                          if ($course_type == 'theory') {
                              echo ' (300 marks)';
                          } else {
                              echo ' (100 marks)';
                          }
                       ?>
                    </td>
                    <td>
                      <?php 
                          if (!empty($course['department_id'])) {
                              $department = getDepartmentById($course['department_id'], $conn);
                              if ($department != 0) {
                                  echo $department['department_code'];
                              } else {
                                  echo 'N/A';
                              }
                          } else {
                              echo 'N/A';
                          }
                       ?>
                    </td>
                    <td>
                      <?php 
                          echo $course['max_marks'] ?? '300';
                       ?>
                    </td>
                    <td>
                        <a href="course-edit.php?course_id=<?=$course['subject_id']?>"
                           class="btn btn-warning btn-sm">Edit</a>
                           
                        <a href="course-delete.php?course_id=<?=$course['subject_id']?>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                    </td>
                  </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
        
        <?php } else { ?>
            <div class="alert alert-info .w-450 m-5" role="alert">
                No courses found! <a href="course-add.php" class="alert-link">Add the first course</a>
            </div>
        <?php } ?>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(8) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 
    } else {
        header("Location: ../login.php");
        exit;
    } 
} else {
    header("Location: ../login.php");
    exit;
} 