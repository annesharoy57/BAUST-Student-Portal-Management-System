<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])     &&
    isset($_GET['student_id'])) {

    if ($_SESSION['role'] == 'Admin') {
      
       include "../DB_connection.php";
       include "data/subject.php";
       include "data/grade.php";
       include "data/student.php";
       include "data/section.php";
       include "data/department.php";
       include "data/class.php";
       
       $grades = getAllGrades($conn);
       $sections = getAllSections($conn);
       $departments = getAllDepartments($conn);
       $classes = getAllClasses($conn);
       
       $student_id = $_GET['student_id'];
       $student = getStudentById($student_id, $conn);

       if ($student == 0) {
         header("Location: student.php");
         exit;
       }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Edit Student</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    .form-check {
        margin-bottom: 10px;
        padding: 8px;
        border-radius: 5px;
        transition: background-color 0.2s;
    }
    .form-check:hover {
        background-color: #f8f9fa;
    }
    .form-check-input:checked + .form-check-label {
        font-weight: bold;
        color: #0d6efd;
    }
  </style>
</head>
<body>
    <?php 
        include "inc/navbar.php";
     ?>
     <div class="container mt-5">
        <a href="student.php"
           class="btn btn-dark">Go Back</a>

        <form method="post"
              class="shadow p-3 mt-5 form-w" 
              action="req/student-edit.php">
        <h3>Edit Student Info</h3><hr>
        <?php if (isset($_GET['error'])) { ?>
          <div class="alert alert-danger" role="alert">
           <?=$_GET['error']?>
          </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
          <div class="alert alert-success" role="alert">
           <?=$_GET['success']?>
          </div>
        <?php } ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">First name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['fname']?>" 
                         name="fname"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Last name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['lname']?>"
                         name="lname"
                         required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Username</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['username']?>"
                         name="username"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Student Phone Number</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['phone_number'] ?? ''?>"
                         name="phone_number">
                </div>
            </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Address</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['address']?>"
                 name="address"
                 required>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Email address</label>
                  <input type="email" 
                         class="form-control"
                         value="<?=$student['email_address']?>"
                         name="email_address"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Date of birth</label>
                  <input type="date" 
                         class="form-control"
                         value="<?=$student['date_of_birth']?>"
                         name="date_of_birth"
                         required>
                </div>
            </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label><br>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" value="Male"
                   <?=($student['gender'] == 'Male') ? 'checked' : ''?> 
                   name="gender">
            <label class="form-check-label">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" value="Female"
                   <?=($student['gender'] == 'Female') ? 'checked' : ''?> 
                   name="gender">
            <label class="form-check-label">Female</label>
          </div>
        </div>

        <!-- DEPARTMENT SECTION -->
        <div class="mb-3">
          <label class="form-label">Department</label>
          <select class="form-control" name="department_id" required>
            <option value="">Select Department</option>
            <?php 
            if ($departments != 0) {
                foreach($departments as $department) {
            ?>
            <option value="<?=$department['department_id']?>" 
                <?=($student['department_id'] == $department['department_id']) ? 'selected' : ''?>>
                <?=$department['department_code']?> - <?=$department['department_name']?>
            </option>
            <?php 
                }
            }
            ?>
          </select>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Parent first name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['parent_fname']?>"
                         name="parent_fname"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Parent last name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$student['parent_lname']?>"
                         name="parent_lname"
                         required>
                </div>
            </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Parent phone number</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['parent_phone_number'] ?? ''?>"
                 name="parent_phone_number"
                 required>
        </div>

        <hr>
        
        <!-- GRADE AND SECTION SELECTION -->
        <div class="mb-3">
          <label class="form-label">Grade</label>
          <div class="border rounded p-3">
            <div class="row">
              <?php 
              $current_grade = $student['grade'];
              foreach ($grades as $grade){ 
              ?>
              <div class="col-md-3">
                <div class="form-check">
                  <input class="form-check-input" 
                         type="radio"
                         name="grade"
                         <?=($current_grade == $grade['grade_id']) ? 'checked' : ''?>
                         value="<?=$grade['grade_id']?>"
                         id="grade_<?=$grade['grade_id']?>">
                  <label class="form-check-label" for="grade_<?=$grade['grade_id']?>">
                    <?=$grade['level']?>-<?=$grade['term']?>
                  </label>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Section</label>
          <div class="border rounded p-3">
            <div class="row">
              <?php 
              $current_section = $student['section'];
              foreach ($sections as $section){ 
              ?>
              <div class="col-md-3">
                <div class="form-check">
                  <input class="form-check-input" 
                         type="radio"
                         name="section"
                         <?=($current_section == $section['section_id']) ? 'checked' : ''?>
                         value="<?=$section['section_id']?>"
                         id="section_<?=$section['section_id']?>">
                  <label class="form-check-label" for="section_<?=$section['section_id']?>">
                    Section <?=$section['section']?>
                  </label>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>

        <!-- CLASS SELECTION (Optional - if you want to assign specific class) -->
        <div class="mb-3">
          <label class="form-label">Class (Optional)</label>
          <div class="border rounded p-3" style="max-height: 150px; overflow-y: auto;">
            <div class="row">
              <?php 
              $current_class = ''; // Students typically don't have multiple classes
              foreach ($classes as $class){ 
                $grade_data = getGradeById($class['grade'], $conn);
                $section_data = getSectionById($class['section'], $conn);
                $class_display = "Class " . $class['class_id'];
                
                if ($grade_data != 0 && $section_data != 0) {
                    $class_display = "Grade " . $grade_data['level'] . "-" . $grade_data['term'] . " " . $section_data['section'];
                }
              ?>
              <div class="col-md-4">
                <div class="form-check">
                  <input class="form-check-input" 
                         type="radio"
                         name="class_id"
                         value="<?=$class['class_id']?>"
                         id="class_<?=$class['class_id']?>"
                         <?=($current_class == $class['class_id']) ? 'checked' : ''?>>
                  <label class="form-check-label" for="class_<?=$class['class_id']?>">
                    <?=$class_display?>
                  </label>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
          <small class="text-muted">Select the specific class if needed</small>
        </div>

        <input type="hidden"
                value="<?=$student['student_id']?>"
                name="student_id">

        <input type="hidden" 
               name="date_of_joined" 
               value="<?=$student['date_of_joined']?>">

        <button type="submit" class="btn btn-primary">Update Student</button>
     </form>

     <!-- Change Password Form -->
     <form method="post"
           class="shadow p-3 my-5 form-w" 
           action="req/student-change.php"
           id="change_password">
        <h3>Change Password</h3><hr>
          <?php if (isset($_GET['perror'])) { ?>
            <div class="alert alert-danger" role="alert">
             <?=$_GET['perror']?>
            </div>
          <?php } ?>
          <?php if (isset($_GET['psuccess'])) { ?>
            <div class="alert alert-success" role="alert">
             <?=$_GET['psuccess']?>
            </div>
          <?php } ?>

          <div class="mb-3">
            <label class="form-label">Admin password</label>
            <input type="password" 
                   class="form-control"
                   name="admin_pass"
                   required> 
          </div>

          <div class="mb-3">
            <label class="form-label">New password</label>
            <div class="input-group mb-3">
                <input type="text" 
                       class="form-control"
                       name="new_pass"
                       id="passInput"
                       required>
                <button class="btn btn-secondary"
                        id="gBtn"
                        type="button">
                        Random</button>
            </div>
          </div>

          <input type="hidden"
                 value="<?=$student['student_id']?>"
                 name="student_id">

          <div class="mb-3">
            <label class="form-label">Confirm new password</label>
            <input type="text" 
                   class="form-control"
                   name="c_new_pass"
                   id="passInput2"
                   required> 
          </div>
          
          <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>  
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });

        function makePass(length) {
            var result = '';
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
              result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            var passInput = document.getElementById('passInput');
            var passInput2 = document.getElementById('passInput2');
            passInput.value = result;
            passInput2.value = result;
        }

        var gBtn = document.getElementById('gBtn');
        gBtn.addEventListener('click', function(e){
          e.preventDefault();
          makePass(8);
        });
    </script>

</body>
</html>
<?php 
  } else {
    header("Location: student.php");
    exit;
  } 
} else {
  header("Location: student.php");
  exit;
} 
?>