<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])     &&
    isset($_GET['teacher_id'])) {

    if ($_SESSION['role'] == 'Admin') {
      
       include "../DB_connection.php";
       include "data/subject.php";
       include "data/grade.php";
       include "data/section.php";
       include "data/class.php";
       include "data/teacher.php";
       include "data/department.php";
       
       $subjects = getAllSubjects($conn);
       $classes  = getAllClasses($conn);
       $departments = getAllDepartments($conn);
       
       $teacher_id = $_GET['teacher_id'];
       $teacher = getTeacherById($teacher_id, $conn);

       if ($teacher == 0) {
         header("Location: teacher.php");
         exit;
       }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Edit Teacher</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../logo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    .form-check {
        margin-bottom: 10px;
        padding: 8px;
        border-radius: 5px;
        transition: background-color 0.2s;
    }
    .form-check:hover {
        background-color: #f8f9fa;
    }
    .form-check-input:checked + .form-check-label {
        font-weight: bold;
        color: #0d6efd;
    }
    .selected-count {
        font-size: 0.875rem;
        font-weight: bold;
        color: #0d6efd;
        margin-top: 5px;
    }
  </style>
</head>
<body>
    <?php 
        include "inc/navbar.php";
     ?>
     <div class="container mt-5">
        <a href="teacher.php"
           class="btn btn-dark">Go Back</a>

        <form method="post"
              class="shadow p-3 mt-5 form-w" 
              action="req/teacher-edit.php"
              id="teacherForm">
        <h3>Edit Teacher</h3><hr>
        <?php if (isset($_GET['error'])) { ?>
          <div class="alert alert-danger" role="alert">
           <?=$_GET['error']?>
          </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
          <div class="alert alert-success" role="alert">
           <?=$_GET['success']?>
          </div>
        <?php } ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">First name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['fname']?>" 
                         name="fname"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Last name</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['lname']?>"
                         name="lname"
                         required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Username</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['username']?>"
                         name="username"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Employee number</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['employee_number']?>"
                         name="employee_number"
                         required>
                </div>
            </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Address</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$teacher['address']?>"
                 name="address"
                 required>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Phone number</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['phone_number']?>"
                         name="phone_number"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Qualification</label>
                  <input type="text" 
                         class="form-control"
                         value="<?=$teacher['qualification']?>"
                         name="qualification"
                         required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Email address</label>
                  <input type="email" 
                         class="form-control"
                         value="<?=$teacher['email_address']?>"
                         name="email_address"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Department</label>
                  <select class="form-control" name="department_id" required>
                    <option value="">Select Department</option>
                    <?php 
                    if ($departments != 0) {
                        foreach($departments as $department) {
                    ?>
                    <option value="<?=$department['department_id']?>" 
                        <?=($teacher['department_id'] == $department['department_id']) ? 'selected' : ''?>>
                        <?=$department['department_code']?> - <?=$department['department_name']?>
                    </option>
                    <?php 
                        }
                    }
                    ?>
                  </select>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Date of birth</label>
                  <input type="date" 
                         class="form-control"
                         value="<?=$teacher['date_of_birth']?>"
                         name="date_of_birth"
                         required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Date of Joined</label>
                  <input type="date" 
                         class="form-control"
                         value="<?=$teacher['date_of_joined']?>"
                         name="date_of_joined"
                         required>
                </div>
            </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label><br>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" value="Male" 
                   <?=($teacher['gender'] == 'Male') ? 'checked' : ''?> 
                   name="gender">
            <label class="form-check-label">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" value="Female"
                   <?=($teacher['gender'] == 'Female') ? 'checked' : ''?> 
                   name="gender">
            <label class="form-check-label">Female</label>
          </div>
        </div>

        <input type="hidden"
                value="<?=$teacher['teacher_id']?>"
                name="teacher_id">

        <!-- Subjects Section -->
        <div class="mb-3">
          <label class="form-label">Subjects (You can select multiple)</label>
          <div class="border rounded p-3" style="max-height: 200px; overflow-y: auto;">
            <div class="row">
              <?php 
              $subject_ids = [];
              if (!empty($teacher['subjects'])) {
                  $subject_ids = explode(",", trim($teacher['subjects']));
                  $subject_ids = array_filter($subject_ids);
              }
              
              foreach ($subjects as $subject){ 
                $checked = in_array($subject['subject_id'], $subject_ids) ? 'checked' : '';
              ?>
              <div class="col-md-4">
                <div class="form-check">
                  <input class="form-check-input subject-checkbox" 
                         type="checkbox"
                         name="subjects[]"
                         <?=$checked?>
                         value="<?=$subject['subject_id']?>"
                         id="subject_<?=$subject['subject_id']?>">
                  <label class="form-check-label" for="subject_<?=$subject['subject_id']?>">
                    <?=$subject['subject_code']?> - <?=$subject['subject']?>
                  </label>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
          <div class="selected-count" id="subjectCount">
            <?=count($subject_ids)?> subjects selected
          </div>
        </div>

        <!-- Classes Section - CORRECTED -->
        <div class="mb-3">
          <label class="form-label">Classes (You can select multiple)</label>
          <div class="border rounded p-3" style="max-height: 200px; overflow-y: auto;">
            <div class="row">
              <?php 
              $class_ids = [];
              if (!empty($teacher['class'])) {
                  $class_ids = explode(",", trim($teacher['class']));
                  $class_ids = array_filter($class_ids);
              }
              
              foreach ($classes as $class){ 
                $checked = in_array($class['class_id'], $class_ids) ? 'checked' : '';
                $grade = getGradeById($class['grade'], $conn);
                $section = getSectionById($class['section'], $conn);
                $class_display = "Class " . $class['class_id'];
                
                if ($grade != 0 && $section != 0) {
                    $class_display = "Grade " . $grade['level'] . "-" . $grade['term'] . " " . $section['section'];
                } else if ($grade != 0) {
                    $class_display = "Grade " . $grade['level'] . "-" . $grade['term'];
                }
              ?>
              <div class="col-md-4">
                <div class="form-check">
                  <input class="form-check-input class-checkbox" 
                         type="checkbox"
                         name="classes[]"
                         <?=$checked?>
                         value="<?=$class['class_id']?>"
                         id="class_<?=$class['class_id']?>">
                  <label class="form-check-label" for="class_<?=$class['class_id']?>">
                    <?=$class_display?>
                  </label>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
          <div class="selected-count" id="classCount">
            <?=count($class_ids)?> classes selected
          </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Teacher</button>
     </form>

     <!-- Change Password Form -->
     <form method="post"
           class="shadow p-3 my-5 form-w" 
           action="req/teacher-change.php"
           id="change_password">
        <h3>Change Password</h3><hr>
          <?php if (isset($_GET['perror'])) { ?>
            <div class="alert alert-danger" role="alert">
             <?=$_GET['perror']?>
            </div>
          <?php } ?>
          <?php if (isset($_GET['psuccess'])) { ?>
            <div class="alert alert-success" role="alert">
             <?=$_GET['psuccess']?>
            </div>
          <?php } ?>

          <div class="mb-3">
            <label class="form-label">Admin password</label>
            <input type="password" class="form-control" name="admin_pass"> 
          </div>

          <div class="mb-3">
            <label class="form-label">New password</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="new_pass" id="passInput">
                <button class="btn btn-secondary" id="gBtn" type="button">Random</button>
            </div>
          </div>

          <input type="hidden" value="<?=$teacher['teacher_id']?>" name="teacher_id">

          <div class="mb-3">
            <label class="form-label">Confirm new password</label>
            <input type="text" class="form-control" name="c_new_pass" id="passInput2"> 
          </div>
          
          <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(2) a").addClass('active');
        });

        function makePass(length) {
            var result = '';
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
              result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            var passInput = document.getElementById('passInput');
            var passInput2 = document.getElementById('passInput2');
            passInput.value = result;
            passInput2.value = result;
        }

        var gBtn = document.getElementById('gBtn');
        gBtn.addEventListener('click', function(e){
          e.preventDefault();
          makePass(8);
        });

        // Update selected counts
        function updateSelectedCount() {
            const selectedSubjects = document.querySelectorAll('.subject-checkbox:checked').length;
            const selectedClasses = document.querySelectorAll('.class-checkbox:checked').length;
            
            document.getElementById('subjectCount').textContent = selectedSubjects + ' subjects selected';
            document.getElementById('classCount').textContent = selectedClasses + ' classes selected';
        }

        // Add event listeners to checkboxes
        document.querySelectorAll('.subject-checkbox, .class-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectedCount);
        });

        // Initialize counts
        updateSelectedCount();
    </script>

</body>
</html>
<?php 
  } else {
    header("Location: teacher.php");
    exit;
  } 
} else {
    header("Location: teacher.php");
    exit;
} 
?>