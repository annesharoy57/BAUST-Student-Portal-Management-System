<?php 
session_start();
if (isset($_SESSION['r_user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Registrar Office') {
        
        if (isset($_POST['fname'])      &&
            isset($_POST['lname'])      &&
            isset($_POST['username'])   &&
            isset($_POST['student_id']) &&
            isset($_POST['address'])    &&
            isset($_POST['email_address']) &&
            isset($_POST['phone_number']) &&
            isset($_POST['date_of_birth']) &&
            isset($_POST['gender'])     &&
            isset($_POST['date_of_joined']) &&
            isset($_POST['parent_fname']) &&
            isset($_POST['parent_lname']) &&
            isset($_POST['parent_phone_number']) &&
            isset($_POST['department']) &&
            isset($_POST['grade'])      &&
            isset($_POST['section'])) {

            include "../../DB_connection.php";
            include "../data/student.php";

            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['username'];
            $address = $_POST['address'];
            $email = $_POST['email_address'];
            $phone_number = $_POST['phone_number'];
            $gender = $_POST['gender'];
            $date_of_birth = $_POST['date_of_birth'];
            $date_of_joined = $_POST['date_of_joined'];
            $parent_fname = $_POST['parent_fname'];
            $parent_lname = $_POST['parent_lname'];
            $parent_phone_number = $_POST['parent_phone_number'];
            $department_id = $_POST['department'];
            $grade = $_POST['grade'];
            $section = $_POST['section'];
            $student_id = $_POST['student_id'];

            $data = 'student_id=' . $student_id;

            if (empty($fname)) {
                $em = "First name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($lname)) {
                $em = "Last name is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($uname)) {
                $em = "Username is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (!unameIsUnique($uname, $conn, $student_id)) {
                $em = "Username is already taken!";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($address)) {
                $em = "Address is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($email)) {
                $em = "Email is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($department_id)) {
                $em = "Department is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($grade)) {
                $em = "Grade is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else if (empty($section)) {
                $em = "Section is required";
                header("Location: ../student-edit.php?error=$em&$data");
                exit;
            } else {
                // Update student
                $sql = "UPDATE students 
                        SET fname=?, lname=?, username=?, address=?, phone_number=?, email_address=?, 
                            gender=?, date_of_birth=?, date_of_joined=?, department_id=?, grade=?, section=?, 
                            parent_fname=?, parent_lname=?, parent_phone_number=? 
                        WHERE student_id=?";
                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([$fname, $lname, $uname, $address, $phone_number, $email, $gender, 
                              $date_of_birth, $date_of_joined, $department_id, $grade, $section,
                              $parent_fname, $parent_lname, $parent_phone_number, $student_id]);
                
                if ($result) {
                    $sm = "Student updated successfully";
                    header("Location: ../student-edit.php?success=$sm&student_id=$student_id");
                    exit;
                } else {
                    $em = "Error updating student";
                    header("Location: ../student-edit.php?error=$em&student_id=$student_id");
                    exit;
                }
            }

        } else {
            $em = "All fields are required";
            header("Location: ../student.php?error=$em");
            exit;
        }

    } else {
        header("Location: ../../login.php");
        exit;
    } 
} else {
    header("Location: ../../login.php");
    exit;
}
?>