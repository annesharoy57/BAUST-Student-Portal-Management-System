<?php
// Get Department by ID
function getDepartmentById($department_id, $conn){
   $sql = "SELECT * FROM departments WHERE department_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$department_id]);

   if ($stmt->rowCount() == 1) {
     $department = $stmt->fetch();
     return $department;
   } else {
    return 0;
   }
}

// All Departments 
function getAllDepartments($conn){
   $sql = "SELECT * FROM departments ORDER BY department_name ASC";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $departments = $stmt->fetchAll();
     return $departments;
   } else {
    return 0;
   }
}

// Check if the department name is Unique
function departmentNameIsUnique($department_name, $conn, $department_id=0){
   $sql = "SELECT department_name, department_id FROM departments WHERE department_name=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$department_name]);
   
   if ($department_id == 0) {
     return $stmt->rowCount() == 0;
   } else {
     if ($stmt->rowCount() >= 1) {
       $department = $stmt->fetch();
       return $department['department_id'] == $department_id;
     } else {
       return true;
     }
   }
}
?>