<?php
// Get All Sections (distinct)
function getAllSections($conn){
   $sql = "SELECT DISTINCT section_id, section FROM section ORDER BY section ASC";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $sections = $stmt->fetchAll();
     return $sections;
   } else {
    return 0;
   }
}

// Get Section by ID
function getSectionById($section_id, $conn){
   $sql = "SELECT * FROM section WHERE section_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$section_id]);

   if ($stmt->rowCount() == 1) {
     $section = $stmt->fetch();
     return $section;
   } else {
    return 0;
   }
}

// Get Section by section letter
function getSectionByLetter($section_letter, $conn){
   $sql = "SELECT * FROM section WHERE section=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$section_letter]);

   if ($stmt->rowCount() == 1) {
     $section = $stmt->fetch();
     return $section;
   } else {
    return 0;
   }
}
?>