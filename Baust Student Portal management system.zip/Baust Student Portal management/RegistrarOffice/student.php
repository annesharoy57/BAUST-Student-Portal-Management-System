<?php 
session_start();
if (isset($_SESSION['r_user_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Registrar Office') {
       include "../DB_connection.php";
       include "data/student.php";
       include "data/grade.php";
       include "data/department.php";
       include "data/section.php";
       
       $students = getAllStudents($conn);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Office - Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
        if ($students != 0) {
     ?>
     <div class="container mt-5">
        <!-- Header Section -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Student List</h2>
            <div>
                <a href="index.php" class="btn btn-secondary me-2">Go Back</a>
                <a href="student-add.php" class="btn btn-primary">Add New Student</a>
            </div>
        </div>

        <!-- Search Form -->
        <form action="student-search.php" class="mb-4" method="get">
            <div class="input-group">
                <input type="text" 
                       class="form-control"
                       name="searchKey"
                       placeholder="Search by student ID, name, or username...">
                <button class="btn btn-primary" type="submit">
                    <i class="fa fa-search" aria-hidden="true"></i> Search
                </button>
            </div>
        </form>

        <!-- Alerts -->
        <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger mt-3" role="alert">
                <?=$_GET['error']?>
            </div>
        <?php } ?>

        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success mt-3" role="alert">
                <?=$_GET['success']?>
            </div>
        <?php } ?>

        <!-- Students Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Department</th>
                        <th scope="col">Grade</th>
                        <th scope="col">Section</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; foreach ($students as $student ) { 
                        $i++;  
                    ?>
                    <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?=$student['student_id']?></td>
                        <td>
                            <img src="../img/student-<?=$student['gender']?>.png" width="20" height="20" class="me-2">
                            <a href="student-view.php?student_id=<?=$student['student_id']?>" 
                               class="text-decoration-none"
                               title="View Student Profile">
                                <?=$student['fname']?>
                            </a>
                        </td>
                        <td>
                            <a href="student-view.php?student_id=<?=$student['student_id']?>" 
                               class="text-decoration-none"
                               title="View Student Profile">
                                <?=$student['lname']?>
                            </a>
                        </td>
                        <td><?=$student['username']?></td>
                        <td>
                            <?php if (!empty($student['department_code'])) { ?>
                                <?=$student['department_code']?>
                            <?php } else { ?>
                                <span class="text-muted">Not assigned</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php 
                                $grade = $student['grade'];
                                $g_temp = getGradeById($grade, $conn);
                                if ($g_temp != 0) {
                                    echo $g_temp['level'].'-'.$g_temp['term'];
                                } else {
                                    echo '<span class="text-muted">N/A</span>';
                                }
                            ?>
                        </td>
                        <td>
                            <?php 
                            if (!empty($student['section_letter'])) {
                                echo $student['section_letter'];
                            } else {
                                echo '<span class="text-muted">N/A</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="student-edit.php?student_id=<?=$student['student_id']?>" 
                                   class="btn btn-warning btn-sm">Edit</a>
                                <a href="student-delete.php?student_id=<?=$student['student_id']?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Are you sure you want to delete this student?')">Delete</a>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php } else { ?>
            <div class="alert alert-info text-center py-4" role="alert">
                <h4 class="alert-heading">No Students Found</h4>
                <p class="mb-0">There are no students registered in the system yet.</p>
                <hr>
                <a href="student-add.php" class="btn btn-primary mt-2">Add First Student</a>
            </div>
        <?php } ?>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
            $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 
  } else {
    header("Location: ../login.php");
    exit;
  } 
} else {
    header("Location: ../login.php");
    exit;
} 
?>