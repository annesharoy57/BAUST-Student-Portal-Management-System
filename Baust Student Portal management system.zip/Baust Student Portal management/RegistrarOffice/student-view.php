<?php 
session_start();
if (isset($_SESSION['r_user_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Registrar Office') {
      
       include "../DB_connection.php";
       include "data/student.php";
       include "data/grade.php";
       include "data/department.php";
       include "data/section.php";

       if (isset($_GET['student_id'])) {
           $student_id = $_GET['student_id'];
           $student = getStudentById($student_id, $conn);
           
           if ($student == 0) {
               header("Location: student.php");
               exit;
           }
       } else {
           header("Location: student.php");
           exit;
       }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Office - View Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
</head>
<body>
    <?php include "inc/navbar.php"; ?>
     <div class="container mt-5">
        <a href="student.php" class="btn btn-dark mb-3">Go Back</a>
        
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <?php 
                    // Display gender icon with fallback
                    $gender_icon = "../img/student-" . strtolower($student['gender']) . ".png";
                    if (file_exists($gender_icon)) {
                        echo '<img src="' . $gender_icon . '" width="30" height="30" class="me-2">';
                    } else {
                        // Fallback to Font Awesome icons
                        if ($student['gender'] == 'Male') {
                            echo '<i class="fa fa-male me-2" aria-hidden="true"></i>';
                        } else {
                            echo '<i class="fa fa-female me-2" aria-hidden="true"></i>';
                        }
                    }
                    ?>
                    Student Profile
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Personal Information</h5>
                        <table class="table table-borderless">
                            <tr>
                                <td><strong>Student ID:</strong></td>
                                <td><?=$student['student_id']?></td>
                            </tr>
                            <tr>
                                <td><strong>Name:</strong></td>
                                <td><?=$student['fname']?> <?=$student['lname']?></td>
                            </tr>
                            <tr>
                                <td><strong>Username:</strong></td>
                                <td><?=$student['username']?></td>
                            </tr>
                            <tr>
                                <td><strong>Gender:</strong></td>
                                <td>
                                    <?php 
                                    if (file_exists($gender_icon)) {
                                        echo '<img src="' . $gender_icon . '" width="20" height="20" class="me-1">';
                                    }
                                    echo $student['gender']; 
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Date of Birth:</strong></td>
                                <td><?=$student['date_of_birth']?></td>
                            </tr>
                            <tr>
                                <td><strong>Email:</strong></td>
                                <td><?=$student['email_address']?></td>
                            </tr>
                            <tr>
                                <td><strong>Phone:</strong></td>
                                <td><?=$student['phone_number']?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h5>Academic Information</h5>
                        <table class="table table-borderless">
                            <tr>
                                <td><strong>Address:</strong></td>
                                <td><?=$student['address']?></td>
                            </tr>
                            <tr>
                                <td><strong>Department:</strong></td>
                                <td>
                                    <?php 
                                    if (!empty($student['department_code'])) {
                                        echo $student['department_code'];
                                        if (!empty($student['department_name'])) {
                                            echo ' - ' . $student['department_name'];
                                        }
                                    } else {
                                        echo '<span class="text-muted">Not assigned</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Grade:</strong></td>
                                <td>
                                    <?php 
                                        $grade = getGradeById($student['grade'], $conn);
                                        if ($grade != 0) {
                                            echo $grade['level'] . '-' . $grade['term'];
                                        } else {
                                            echo '<span class="text-muted">N/A</span>';
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Section:</strong></td>
                                <td>
                                    <?php 
                                    if (!empty($student['section_letter'])) {
                                        echo $student['section_letter'];
                                    } else {
                                        echo '<span class="text-muted">N/A</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Date Joined:</strong></td>
                                <td><?=date('Y-m-d', strtotime($student['date_of_joined']))?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <hr>
                <h5>Parent Information</h5>
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <td><strong>Parent Name:</strong></td>
                                <td><?=$student['parent_fname']?> <?=$student['parent_lname']?></td>
                            </tr>
                            <tr>
                                <td><strong>Parent Phone:</strong></td>
                                <td><?=$student['parent_phone_number']?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="student-edit.php?student_id=<?=$student['student_id']?>" class="btn btn-warning">Edit</a>
                <a href="student.php" class="btn btn-secondary">Back to List</a>
            </div>
        </div>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Add Font Awesome for fallback icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</body>
</html>
<?php 
  }else {
    header("Location: ../login.php");
    exit;
  } 
}else {
    header("Location: ../login.php");
    exit;
} 
?>