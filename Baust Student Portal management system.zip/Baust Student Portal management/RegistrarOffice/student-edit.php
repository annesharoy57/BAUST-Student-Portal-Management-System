<?php 
session_start();
if (isset($_SESSION['r_user_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Registrar Office') {
      
       include "../DB_connection.php";
       include "data/student.php";
       include "data/grade.php";
       include "data/section.php";
       include "data/department.php";

       if (isset($_GET['student_id'])) {
           $student_id = $_GET['student_id'];
           $student = getStudentById($student_id, $conn);
           
           if ($student == 0) {
               header("Location: student.php");
               exit;
           }
       } else {
           header("Location: student.php");
           exit;
       }

       $grades = getAllGrades($conn);
       $sections = getAllSections($conn);
       $departments = getAllDepartments($conn);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Office - Edit Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../baustlogo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php include "inc/navbar.php"; ?>
     <div class="container mt-5">
        <a href="student.php"
           class="btn btn-dark">Go Back</a>

        <form method="post"
              class="shadow p-3 mt-5 form-w" 
              action="req/student-edit.php">
        <h3>Edit Student</h3><hr>
        <?php if (isset($_GET['error'])) { ?>
          <div class="alert alert-danger" role="alert">
           <?=$_GET['error']?>
          </div>
        <?php } ?>
        <?php if (isset($_GET['success'])) { ?>
          <div class="alert alert-success" role="alert">
           <?=$_GET['success']?>
          </div>
        <?php } ?>
        
        <input type="hidden" name="student_id" value="<?=$student['student_id']?>">
        
        <div class="mb-3">
          <label class="form-label">First name</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['fname']?>" 
                 name="fname">
        </div>
        <div class="mb-3">
          <label class="form-label">Last name</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['lname']?>"
                 name="lname">
        </div>
        <div class="mb-3">
          <label class="form-label">Address</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['address']?>"
                 name="address">
        </div>
        <div class="mb-3">
          <label class="form-label">Email address</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['email_address']?>"
                 name="email_address">
        </div>
        <div class="mb-3">
          <label class="form-label">Phone Number</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['phone_number']?>"
                 name="phone_number">
        </div>
        <div class="mb-3">
          <label class="form-label">Date of birth</label>
          <input type="date" 
                 class="form-control"
                 value="<?=$student['date_of_birth']?>"
                 name="date_of_birth">
        </div>
        <div class="mb-3">
          <label class="form-label">Gender</label><br>
          <input type="radio"
                 value="Male"
                 <?=$student['gender'] == 'Male' ? 'checked' : ''?>
                 name="gender"> Male
                 &nbsp;&nbsp;&nbsp;&nbsp;
          <input type="radio"
                 value="Female"
                 <?=$student['gender'] == 'Female' ? 'checked' : ''?>
                 name="gender"> Female
        </div><br><hr>
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['username']?>"
                 name="username">
        </div><br><hr>
        <div class="mb-3">
          <label class="form-label">Parent first name</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['parent_fname']?>"
                 name="parent_fname">
        </div>
        <div class="mb-3">
          <label class="form-label">Parent last name</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['parent_lname']?>"
                 name="parent_lname">
        </div>
        <div class="mb-3">
          <label class="form-label">Parent phone number</label>
          <input type="text" 
                 class="form-control"
                 value="<?=$student['parent_phone_number']?>"
                 name="parent_phone_number">
        </div><br><hr>
        
        <div class="mb-3">
          <label class="form-label">Department</label>
          <select name="department" class="form-select" required>
            <option value="">Select Department</option>
            <?php if ($departments != 0): ?>
              <?php foreach ($departments as $department): ?>
                <option value="<?=$department['department_id']?>" 
                    <?=$student['department_id'] == $department['department_id'] ? 'selected' : ''?>>
                  <?=$department['department_code']?> - <?=$department['department_name']?>
                </option>
              <?php endforeach ?>
            <?php endif ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Grade</label>
          <div class="row row-cols-5">
            <?php foreach ($grades as $grade): ?>
            <div class="col">
              <input type="radio"
                     name="grade"
                     value="<?=$grade['grade_id']?>"
                     <?=$student['grade'] == $grade['grade_id'] ? 'checked' : ''?>>
                     <?=$grade['level']?>-<?=$grade['term']?>
            </div>
            <?php endforeach ?>
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Section</label>
          <div class="row row-cols-5">
            <?php foreach ($sections as $section): ?>
            <div class="col">
              <input type="radio"
                     name="section"
                     value="<?=$section['section_id']?>"
                     <?=$student['section'] == $section['section_id'] ? 'checked' : ''?>>
                     <?=$section['section']?>
            </div>
            <?php endforeach ?>
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Date of Joined</label>
          <input type="date" 
                 class="form-control"
                 value="<?=$student['date_of_joined']?>"
                 name="date_of_joined">
        </div>

        <button type="submit" class="btn btn-primary">Update Student</button>
     </form>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 
  }else {
    header("Location: ../login.php");
    exit;
  } 
}else {
    header("Location: ../login.php");
    exit;
} 
?>