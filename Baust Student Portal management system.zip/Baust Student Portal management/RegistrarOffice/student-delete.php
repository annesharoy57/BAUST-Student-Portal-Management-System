<?php 
session_start();
if (isset($_SESSION['r_user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'Registrar Office') {
        
        if (isset($_GET['student_id'])) {
            include "../DB_connection.php";
            include "data/student.php";
            
            $student_id = $_GET['student_id'];
            
            // Check if student exists
            $student = getStudentById($student_id, $conn);
            if ($student == 0) {
                header("Location: student.php?error=Student not found!");
                exit;
            }
            
            // Delete student
            $sql = "DELETE FROM students WHERE student_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$student_id]);
            
            $sm = "Student deleted successfully";
            header("Location: student.php?success=$sm");
            exit;
            
        } else {
            header("Location: student.php?error=Student ID required!");
            exit;
        }

    } else {
        header("Location: ../login.php");
        exit;
    } 
} else {
    header("Location: ../login.php");
    exit;
}
?>