-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2023 at 02:16 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(127) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(127) NOT NULL,
  `lname` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `fname`, `lname`) VALUES
(1, 'Mou', '$2y$10$H7obJEdmLzqqcPy7wQWhsOLUvrgzC8f1Y1or2Gxaza5z1PT0tvLy6', 'Mou', 'Akter');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `grade` int(11) NOT NULL,
  `section` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

I-- Insert data into class table
-- Insert data with specific class_id values
INSERT INTO class (class_id, grade, section) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 2),
(6, 2, 3),
(7, 3, 1),
(8, 3, 2),
(9, 3, 3),
(10, 4, 1),
(11, 4, 2),
(12, 4, 3),
(13, 5, 1),
(14, 5, 2),
(15, 5, 3),
(16, 6, 1),
(17, 6, 2),
(18, 7, 1),
(19, 7, 2),
(20, 8, 1),
(21, 8, 2);
-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `grade_id` int(11) NOT NULL,
  `term` varchar(31) NOT NULL,
  `level` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

-- Insert data with specific grade_id values
INSERT INTO grade (grade_id, term, level) VALUES
(1, 'I', '1'),
(2, 'II', '1'),
(3, 'I', '2'),
(4, 'II', '2'),
(5, 'I', '3'),
(6, 'II', '3'),
(7, 'I', '4'),
(8, 'II', '4');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int(11) NOT NULL,
  `sender_full_name` varchar(100) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `message`
--

-- Insert data with specific message_id values (continuing from existing IDs)
INSERT INTO `message` (`message_id`, `sender_full_name`, `sender_email`, `message`, `date_time`) VALUES
(4, 'Annesha', 'annesha@gmail.com', 'Hello,mou', '2025-08-17 23:39:15'),
(5, 'Saba', 'saba@gmail.com', 'Hi.Mou', '2025-08-17 23:49:19');

-- --------------------------------------------------------

--
-- Table structure for table `registrar_office`
--

CREATE TABLE `registrar_office` (
  `r_user_id` int(11) NOT NULL,
  `username` varchar(127) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(31) NOT NULL,
  `lname` varchar(31) NOT NULL,
  `address` varchar(31) NOT NULL,
  `employee_number` int(11) NOT NULL,
  `date_of_birth` date NOT NULL,
  `phone_number` varchar(31) NOT NULL,
  `qualification` varchar(31) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `date_of_joined` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrar_office`
--

-- Insert new data into registrar_office table
INSERT INTO `registrar_office` (`username`, `password`, `fname`, `lname`, `address`, `employee_number`, `date_of_birth`, `phone_number`, `qualification`, `gender`, `email_address`, `date_of_joined`) VALUES
('roman88', '$2y$10$7XhzOu.3OgHPFv7hKjvfUu3waU.8j6xTASj4yIWMfo....', 'Roman', 'Raihan', 'Rajshahi', 25078, '1999-06-11', '01742809971', 'BSc, BA', 'Male', 'lima24@.com', '2022-11-12 23:06:18'),
('shabnom', '$2y$10$t0SCfeXNcyiO9hdzNTKKB.j2xlE2yt8Hm2.0AWJR5kS...', 'Shabnom', 'Maria', 'Saidpur', 1, '1999-09-26', '01742809956', 'diploma', 'Female', 'sbmaria@j.com', '2022-10-23 01:03:25');
-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `section` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section`) VALUES
(1, 'A'),
(2, 'B'),
(3, 'C'),
(6, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `current_year` int(11) NOT NULL,
  `current_semester` varchar(11) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `slogan` varchar(300) NOT NULL,
  `about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `current_year`, `current_semester`, `school_name`, `slogan`, `about`) VALUES
(1, 2023, 'II', 'Y School', 'Lux et Veritas Light and Truth', 'This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `username` varchar(127) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(127) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `grade` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `address` varchar(31) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `date_of_joined` timestamp NULL DEFAULT current_timestamp(),
  `parent_fname` varchar(127) NOT NULL,
  `parent_lname` varchar(127) NOT NULL,
  `parent_phone_number` varchar(31) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `username`, `password`, `fname`, `lname`, `grade`, `section`, `address`, `gender`, `email_address`, `date_of_birth`, `date_of_joined`, `parent_fname`, `parent_lname`, `parent_phone_number`) VALUES
(1, 'john', '$2y$10$xmtROY8efWeORYiuQDE3SO.eZwscao20QNuLky1Qlr88zDzNNq4gm', 'John', 'Doe', 1, 1, 'California,  Los angeles', 'Male', 'abas55@ab.com', '2012-09-12', '2019-12-11 14:16:44', 'Doe', 'Mark', '09393'),
(3, 'abas', '$2y$10$KLFheMWgpLfoiqMuW2LQxOPficlBiSIJ9.wE2qr5yJUbAQ.5VURoO', 'Abas', 'A.', 2, 1, 'Berlin', 'Male', 'abas@ab.com', '2002-12-03', '2021-12-01 14:16:51', 'dsf', 'dfds', '7979'),
(4, 'jo', '$2y$10$pYyVlWg9jxkT0u/4LrCMS.ztMaOvgyol1hgNt.jqcFEqUC7yZLIYe', 'John3', 'Doe', 1, 1, 'California,  Los angeles', 'Female', 'jo@jo.com', '2013-06-13', '2022-09-10 13:48:49', 'Doe', 'Mark', '074932040'),
(5, 'jo2', '$2y$10$lRQ58lbak05rW7.be8ok4OaWJcb9znRp9ra.qXqnQku.iDrA9N8vy', 'Jhon', 'Doe', 1, 1, 'UK', 'Male', 'jo@jo.com', '1990-02-15', '2023-02-12 18:11:26', 'Doe', 'Do', '0943568654');

-- --------------------------------------------------------

--
-- Table structure for table `student_score`
--

CREATE TABLE `student_score` (
  `id` int(11) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `results` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_score`
--

INSERT INTO `student_score` (`id`, `semester`, `year`, `student_id`, `teacher_id`, `subject_id`, `results`) VALUES
(1, 'II', 2021, 1, 1, 1, '10 15,15 20,10 10,10 20,30 35'),
(2, 'II', 2023, 1, 1, 4, '15 20,4 5'),
(3, 'I', 2022, 1, 1, 5, '10 20,50 50');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject` varchar(31) NOT NULL,
  `subject_code` varchar(31) NOT NULL,
  `grade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
INSERT INTO subjects (subject, subject_code, grade, credit_hours, course_type, department_id, max_marks) VALUES
('Introduction to Computer System Sessional', 'CSE 1100', '1-I', 1.50, 'sessional', 1, 100),
('Structured Programming Language', 'CSE 1101', '1-I', 3.00, 'theory', 1, 300),
('Structured Programming Language Sessional', 'CSE 1102', '1-I', 1.50, 'sessional', 1, 100),
('Introduction to Electrical Engineering', 'EEE 1163', '1-I', 3.00, 'theory', 1, 300),
('Introduction to Electrical Engineering Sessional', 'EEE 1164', '1-I', 1.50, 'sessional', 1, 100),
('Differential Calculus, Integral Calculus, and Coordinate Geometry', 'MATH 1141', '1-I', 3.00, 'theory', 1, 300),
('Physics', 'PHY 1103', '1-I', 3.00, 'theory', 1, 300),
('Physics Sessional', 'PHY 1104', '1-I', 0.75, 'sessional', 1, 100),
('Engineering Drawing and CAD Sessional', 'CE 1250', '1-II', 1.50, 'sessional', 1, 100),
('Discrete Mathematics', 'CSE 1201', '1-II', 3.00, 'theory', 1, 300),
('Object Oriented Programming Language', 'CSE 1203', '1-II', 3.00, 'theory', 1, 300),
('Object Oriented Programming Language Sessional I', 'CSE 1204', '1-II', 1.50, 'sessional', 1, 100),
('Numerical Methods', 'CSE 1208', '1-II', 1.50, 'sessional', 1, 100),
('Electronic Circuits', 'EEE 1269', '1-II', 3.00, 'theory', 1, 300),
('Electronic Circuits Sessional', 'EEE 1270', '1-II', 1.50, 'sessional', 1, 100),
('English', 'ENG 1201', '1-II', 3.00, 'theory', 1, 300),
('Developing English Skill Sessional', 'ENG 1202', '1-II', 0.75, 'sessional', 1, 100),
('Ordinary Differential Equations and Partial Differential Equations', 'MATH 1203', '1-II', 3.00, 'theory', 1, 300),
('Chemistry', 'CHEM 2101', '2-I', 3.00, 'theory', 1, 300),
('Software Development Project-I', 'CSE 2100', '2-I', 1.00, 'sessional', 1, 100),
('Digital Logic Design', 'CSE 2101', '2-I', 3.00, 'theory', 1, 300),
('Digital Logic Design Sessional', 'CSE 2102', '2-I', 1.50, 'sessional', 1, 100),
('Data Structures and Algorithm I', 'CSE 2103', '2-I', 3.00, 'theory', 1, 300),
('Data Structures and Algorithm I Sessional', 'CSE 2104', '2-I', 1.50, 'sessional', 1, 100),
('Applied Statistics for Computer Science', 'CSE 2105', '2-I', 3.00, 'theory', 1, 300),
('Object Oriented Programming Language Sessional II', 'CSE 2106', '2-I', 1.50, 'sessional', 1, 100),
('Compiler Sessional', 'CSE 3110', '2-I', 0.75, 'sessional', 1, 100),
('Vector Calculus, Linear Algebra and Complex Variable', 'MATH 2145', '2-I', 3.00, 'theory', 1, 300),
('Data Structures and Algorithm II', 'CSE 2201', '2-II', 3.00, 'theory', 1, 300),
('Data Structures and Algorithm II Sessional', 'CSE 2202', '2-II', 1.50, 'sessional', 1, 100),
('Theory of Computation', 'CSE 2203', '2-II', 3.00, 'theory', 1, 300),
('Database Management System', 'CSE 2205', '2-II', 3.00, 'theory', 1, 300),
('Database Management System Sessional', 'CSE 2206', '2-II', 1.50, 'sessional', 1, 100),
('Electrical Drives and Instrumentation', 'EEE 2269', '2-II', 3.00, 'theory', 1, 300),
('Electrical Drives and Instrumentation Sessional', 'EEE 2270', '2-II', 0.75, 'sessional', 1, 100),
('Laplace Transformation and Fourier Analysis', 'MATH 2245', '2-II', 3.00, 'theory', 1, 300),
('Software Development Project-II', 'CSE 3100', '3-I', 1.00, 'sessional', 1, 100),
('Software Engineering', 'CSE 3101', '3-I', 3.00, 'theory', 1, 300),
('Software Engineering Sessional', 'CSE 3102', '3-I', 0.75, 'sessional', 1, 100),
('Microprocessors, Microcontroller and Embedded System', 'CSE 3103', '3-I', 3.00, 'theory', 1, 300),
('Microprocessors, Microcontroller and Embedded System Sessional', 'CSE 3104', '3-I', 0.75, 'sessional', 1, 100),
('Computer Architecture', 'CSE 3105', '3-I', 3.00, 'theory', 1, 300),
('Data Communication', 'CSE 3107', '3-I', 3.00, 'theory', 1, 300),
('Compiler', 'CSE 3109', '3-I', 3.00, 'theory', 1, 300),
('Technical Writing and Presentation', 'CSE 3112', '3-I', 1.00, 'sessional', 1, 100),
('Basic Mechanical Engineering', 'ME 3181', '3-I', 3.00, 'theory', 1, 300);
--


-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE teachers (
    teacher_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(127) NOT NULL,
    password VARCHAR(255) NOT NULL,
    class VARCHAR(31),
    fname VARCHAR(127) NOT NULL,
    lname VARCHAR(127) NOT NULL,
    subjects VARCHAR(31),
    address VARCHAR(31),
    employee_number INT(11) NOT NULL,
    date_of_birth DATE,
    phone_number VARCHAR(31),
    qualification VARCHAR(127),
    department VARCHAR(100),
    gender VARCHAR(7) NOT NULL,
    email_address VARCHAR(255),
    date_of_joined DATE,
    department_id INT(11),
    UNIQUE KEY username_unique (username),
    UNIQUE KEY employee_number_unique (employee_number)
);-- Insert Annesha Roy
INSERT INTO teachers (
    username, password, class, fname, lname, subjects, address, 
    employee_number, date_of_birth, phone_number, qualification, 
    department, gender, email_address, date_of_joined, department_id
) VALUES (
    'Annesha', 
    '$2y$10$JruTW/rNZ6CVO4nxYWCrn.GJpiIKMACEPYrK00S7Dk/fkbJIdYau2', 
    '1,2,3,4,5,6,7,8,9,10,11,12,13', 
    'Annesha', 
    'Roy', 
    '18,26,1,2,3,10,11,12,25,28,19,2', 
    'Saidpur', 
    1, 
    '2005-09-12', 
    '0945739', 
    'BSc', 
    'CSE', 
    'Female', 
    'annesha@gmail.com', 
    '2023-10-12', 
    1
);

-- Insert Ariyan Mahfuz
INSERT INTO teachers (
    username, password, class, fname, lname, subjects, address, 
    employee_number, date_of_birth, phone_number, qualification, 
    department, gender, email_address, date_of_joined, department_id
) VALUES (
    'ariyan', 
    '$2y$10$cMSKcHEJcg3K6wbVcxcXGuksgU39i70aEQVKN7ZHrzqTH9oAc3y5m', 
    '16', 
    'Ariyan', 
    'Mahfuz', 
    '12,13', 
    'Rangpur', 
    2, 
    '2003-09-16', 
    '01725443140', 
    'BSc,', 
    'EEE', 
    'Male', 
    'ariyan05@gmail.com', 
    '2022-09-09', 
    2
);

-- Insert Jannatun Dipa
INSERT INTO teachers (
    username, password, class, fname, lname, subjects, address, 
    employee_number, date_of_birth, phone_number, qualification, 
    department, gender, email_address, date_of_joined, department_id
) VALUES (
    'dipa', 
    '$2y$10$MBngKxI1SZ63Prr1arWZl.bzUwjsU3p.cqIlh6.ze.siVvtbEGp82', 
    '7,8,9,10,11,12,13,14,15,16', 
    'Jannatun', 
    'Dipa', 
    '21,22,31,32,37,38,39,40,41,42,4', 
    'dinajpur', 
    57, 
    '2000-01-29', 
    '01742809971', 
    'BSc, BA', 
    NULL, 
    'Female', 
    'dipa27@ab.com', 
    '2023-06-22', 
    1
);
--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `registrar_office`
--
ALTER TABLE `registrar_office`
  ADD PRIMARY KEY (`r_user_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `student_score`
--
ALTER TABLE `student_score`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registrar_office`
--
ALTER TABLE `registrar_office`
  MODIFY `r_user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_score`
--
ALTER TABLE `student_score`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- Add new columns to your existing subjects table
ALTER TABLE subjects 
ADD COLUMN credit_hours DECIMAL(3,2) DEFAULT 3.00,
ADD COLUMN course_type ENUM('theory', 'sessional') DEFAULT 'theory',
ADD COLUMN department_id INT,
ADD COLUMN max_marks INT DEFAULT 300;

-- Modify your existing student_score table to add detailed marks columns
ALTER TABLE student_score 
ADD COLUMN ct1 DECIMAL(5,2),
ADD COLUMN ct2 DECIMAL(5,2),
ADD COLUMN ct3 DECIMAL(5,2),
ADD COLUMN assignment DECIMAL(5,2),
ADD COLUMN mid_term DECIMAL(5,2),
ADD COLUMN attendance DECIMAL(5,2),
ADD COLUMN final_exam DECIMAL(5,2),
ADD COLUMN total_marks DECIMAL(5,2),
ADD COLUMN percentage DECIMAL(5,2),
ADD COLUMN letter_grade VARCHAR(5),
ADD COLUMN grade_point DECIMAL(3,2),
ADD COLUMN credit_hours DECIMAL(3,2) DEFAULT 3.00,
MODIFY COLUMN results VARCHAR(512); -- Keep for backward compatibility

-- Create marks distribution table (for theory courses breakdown)
CREATE TABLE marks_distribution (
    distribution_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT,
    best_two_ct DECIMAL(5,2) DEFAULT 20.00,
    assignment DECIMAL(5,2) DEFAULT 15.00,
    mid_term DECIMAL(5,2) DEFAULT 45.00,
    attendance DECIMAL(5,2) DEFAULT 20.00,
    final_exam DECIMAL(5,2) DEFAULT 180.00,
    total DECIMAL(5,2) DEFAULT 300.00,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);

-- Keep student_gpa table for GPA tracking
CREATE TABLE student_gpa (
    gpa_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    semester VARCHAR(20),
    total_credits DECIMAL(5,2),
    total_quality_points DECIMAL(5,2),
    gpa DECIMAL(3,2),
    cgpa DECIMAL(3,2),
    academic_year VARCHAR(20),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);
CREATE TABLE teacher_subject (
    id INT PRIMARY KEY AUTO_INCREMENT,
    teacher_id INT,
    subject_id INT,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    UNIQUE KEY unique_teacher_subject (teacher_id, subject_id)
);

CREATE TABLE student_fees (
    fee_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(50),
    semester INT,
    academic_year VARCHAR(20),
    total_fee DECIMAL(10,2),
    paid_amount DECIMAL(10,2),
    due_amount DECIMAL(10,2),
    payment_status ENUM('paid', 'partial', 'unpaid'),
    payment_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE  `departments` (
    `department_id` INT(11) NOT NULL AUTO_INCREMENT,
    `department_name` VARCHAR(255) NOT NULL,
    `department_code` VARCHAR(10) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`department_id`),
    UNIQUE KEY `unique_department_code` (`department_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data with specific department_id values
INSERT INTO `departments` (`department_id`, `department_name`, `department_code`) VALUES
(1, 'Computer Science & Engineering', 'CSE'),
(2, 'Electrical & Electronic Engineering', 'EEE'),
(3, 'Civil Engineering', 'CE'),
(4, 'Mechanical Engineering', 'ME'),
(5, 'Industrial & Production Engineering', 'IPE'),
(6, 'Bachelor of Business Administration', 'BBA'),
(7, 'Department of English', 'ENG'),
(8, 'Arts & Social Sciences', 'AIS');